import { l as normalizeOptionalString } from "./string-coerce-1VuiLaaR.mjs";
import { a as extractErrorCode, i as collectNestedErrorCandidates } from "./error-coercion-W9BtigRm.mjs";
import { t as runInDetachedAsyncContext } from "./detached-async-context-D4YGqfxh.mjs";
import { t as createDeferredCore } from "./deferred-D0La5CRk.mjs";
import { s as trackAsyncWork } from "./async-work-scope-DDiH0P7W.mjs";
import { a as asOptionalRecord, c as isRecord } from "./record-coerce-TIsquoVR.mjs";
import { t as stableStringify } from "./stable-stringify-Djn3uxNo.mjs";
import { r as truncateUtf16Safe } from "./utf16-slice-D_ngcYKd.mjs";
import { i as resolveRuntimeWorkerUrl } from "./runtime-worker-url-CFqA9Dvi.mjs";
import { r as resolveStateDir } from "./state-dir-CYkBUd_G.mjs";
import { t as formatErrorMessage } from "./errors-BvOkmQM5.mjs";
import { a as executeSqliteQueryTakeFirstSync, s as iterateSqliteQuerySync } from "./kysely-sync-DUWzQvCU.mjs";
import { p as readSqliteNativeMutationRevision } from "./sqlite-schema-facts-BVf0E_0z.mjs";
import { d as readDatabasePathIdentitySync, r as assertExistingDatabaseIdentity } from "./sqlite-worker-identity-BRNRpRyc.mjs";
import { a as createSqliteLifecycleAggregateError } from "./sqlite-lifecycle-errors-DuOygjcn.mjs";
import { t as createSubsystemLogger } from "./subsystem-4NzR43uz.mjs";
import { s as withSqliteCommittedPublications } from "./sqlite-post-commit-DENvzR6w.mjs";
import { n as sha256Hex } from "./node-crypto-BG4u3UnX.mjs";
import { n as runtimeProcessEntrypoints } from "./runtime-process-entrypoints-De68tE_W.mjs";
import { g as SessionPendingInputCustodyError } from "./openclaw-state-worker-error-Bi-BnNrV.mjs";
import { t as SessionTranscriptWriterClaimReboundError } from "./session-transcript-writer-claim-error-eP-_sDN9.mjs";
import { i as getOrCreatePromise } from "./lazy-promise-DGqyc4Y4.mjs";
import { n as ok, t as err } from "./result-BQGgYouL.mjs";
import { n as normalizeAgentId } from "./agent-id-D1-Q6vR4.mjs";
import { r as isIncognitoSessionKey } from "./session-key-CmZ4o9-l.mjs";
import { l as resolveAgentIdFromSessionKey, o as classifySessionKeyShape } from "./session-key-DY3MOX4N.mjs";
import { h as parseAgentSessionKey } from "./session-key-utils-CDyBC9Gn.mjs";
import { i as listAgentIds } from "./agent-roster-DH6r_8f4.mjs";
import { c as resolveSessionStorePathCore } from "./paths-Bonddxfk.mjs";
import { T as tryResolveLegacyCompatibilityAgentId, t as AgentSelectionRequiredError } from "./agent-scope-config-BEk6-ThS.mjs";
import { a as readOpenClawAgentDatabaseIdentity } from "./openclaw-agent-db-identity-BlmER9-X.mjs";
import { o as registerOpenClawAgentDatabaseAsyncResource } from "./openclaw-agent-db-resources-Cm-sH7kg.mjs";
import { c as getOpenClawAgentDatabaseValidation } from "./openclaw-agent-db-validation-cache-CHrtutWN.mjs";
import { i as isIncognitoOpenClawAgentSqlitePath, l as resolveOpenClawAgentSqlitePath } from "./openclaw-agent-db.paths-BbmZlEP5.mjs";
import { n as withOpenClawAgentDatabaseReadOnly, t as retainOpenClawAgentDatabaseReadOnly } from "./openclaw-agent-db-readonly-DAqV3tqr.mjs";
import { c as SqliteWorkerError, l as hasSqliteWorkerOutcomeUnknown } from "./sqlite-worker-contract-C51cJHzg.mjs";
import { a as observeSqliteWorkerCommittedFacts } from "./sqlite-worker-operation-admission-C5lBzzTk.mjs";
import { i as sessionChanges } from "./session-row-changes-Dj2yVWo-.mjs";
import { r as cloneEnvWithPlatformSemantics } from "./config-env-vars-BzUE_dOh.mjs";
import { c as runOpenClawAgentWriteTransaction, d as withOpenClawAgentDatabaseRuntime, i as getOpenClawAgentDatabaseIfOpen, o as openOpenClawAgentDatabase } from "./openclaw-agent-db-DWI9Bgur.mjs";
import { u as deferOpenClawAgentPostCommitPublication } from "./openclaw-agent-db-lifecycle-C9dal1XJ.mjs";
import { n as runOpenClawAgentWriteAdmission } from "./openclaw-agent-write-admission-CXJiE5VB.mjs";
import { n as sessionEntrySnapshotColumns, t as attachSessionEntrySnapshots } from "./session-entry-snapshots-CZRgb8_2.mjs";
import { c as transcriptEventJsonSql } from "./transcript-payload-K8XYDkGU.mjs";
import { l as resolveTerminalAssistantTranscriptRunId, n as attachSessionTranscriptRunId, r as emitSessionTranscriptUpdate, s as readSessionTranscriptRunId } from "./transcript-events-DSEdnn1V.mjs";
import "./legacy.default-agent-owner-CMzbXvh6.mjs";
import { a as normalizeStoreSessionKey, c as resolveSessionStoreEntryCore, d as sessionDeliveryOrigin, l as deliveryContextFromSession } from "./store-entry-ClyG-tia.mjs";
import { i as toDatabaseOptions, r as resolveSqliteSessionKey, t as getSessionKysely } from "./session-accessor.sqlite-scope-helpers-CfDTAEsL.mjs";
import { n as projectSqliteSessionOwner } from "./session-accessor.sqlite-owner-projection-BlnyvWMj.mjs";
import { c as normalizeSessionDeliveryState } from "./delivery-context.shared-BYdFKp9k.mjs";
import { i as projectCanonicalSessionEntryShape } from "./store-entry-shape-D9NfUfaQ.mjs";
import { n as parseSessionEntryJson } from "./session-accessor.sqlite-status-B9-XRjlV.mjs";
import { f as scanCanonicalSqliteSessionEntries } from "./session-canonical-key-BTldoZ8u.mjs";
import { n as captureSessionStoreCandidateIdentities, t as assertSessionStoreReadCandidate } from "./session-store-read-candidates-CXD-JYGz.mjs";
import { n as captureSessionTranscriptTargetBinding, r as sameSessionTranscriptStorageEnvironment, t as captureSessionTranscriptStorageEnvironment } from "./transcript-target-binding-DpcuSIFy.mjs";
import { r as resolvePersistedSessionStoreOwnerForTarget } from "./session-store-owner-DZX-SiyK.mjs";
import { d as getAgentEventLifecycleGeneration, t as assertAgentRunLifecycleGenerationCurrent } from "./agent-events-jWdQ_ESE.mjs";
import { l as releaseSessionSourceAuthorities, s as prepareSessionSourceAuthority, t as acceptSessionSourceValidation } from "./session-source-authority-h1UO3u0I.mjs";
import { r as getRuntimeConfig } from "./io.runtime-B134MOMz.mjs";
import "./io-BGddrCVX.mjs";
import { c as normalizeGatewayClientMode, s as normalizeGatewayClientId } from "./client-info-BgcoFakQ.mjs";
import { i as SessionParticipantSchema } from "./session-participant-DFNwXH4D.mjs";
import { n as captureOpenClawAgentDatabaseExecution, s as readPendingInputMutationReceipt } from "./openclaw-agent-execution-C2B2fucX.mjs";
import { i as rethrowIncognitoSessionError, r as IncognitoSessionSyncAccessError } from "./incognito-session-error-BUzgcwoZ.mjs";
import { n as openOpenClawAgentSqliteWorkerStore, t as executeOpenClawAgentWorkerPublication } from "./openclaw-agent-worker-store-BE9hhRoh.mjs";
import { n as getCliHistoryWriter } from "./cli-history-boundary-CK2yr7Tm.mjs";
import { a as captureSessionTranscriptSourcePublication, c as getOwnedSessionTranscriptWriterFence, d as withOwnedSessionTranscriptWriterFence, l as runWithOwnedSessionTranscriptWrite, o as getOwnedSessionTranscriptInitialWriter, r as captureOwnedTranscriptWriteAssertion, t as assertOwnedTranscriptWriteCommit } from "./transcript-write-context-DwwjCPCE.mjs";
import { n as hasSqliteCommitReceiptCoverage } from "./sqlite-commit-receipt-DafgyYOc.mjs";
import { n as assertSessionEntryCurrentAdmission } from "./session-entry-current-admission-D6fbI5HG.mjs";
import { a as SessionWorkStartChangedError } from "./work-start-error-Dh9d0ImY.mjs";
import { d as readUserProfileAliases, o as prepareUserProfileCatalog } from "./user-profile-list-B5oc-3kB.mjs";
import { t as lazyCompile } from "./protocol-validator-BeXu4Ype.mjs";
import { a as prepareSqliteTranscriptReadScope, d as resolveSqliteTranscriptScope, f as resolveSqliteWriteAdmissionScope, i as prepareSqliteScope, m as transcriptWriteScopeIsCurrent, n as captureLifecycleDatabaseScope, p as runExclusiveSqliteSessionWrite, s as resolveSqliteScope, t as assertSqliteTranscriptWriteIdentity, u as resolveSqliteTranscriptReadScope } from "./session-accessor.sqlite-scope-BkgwxatT.mjs";
import { l as isInternalSessionEffectsKey } from "./session-accessor.sqlite-participant-projection-BXRIuuEE.mjs";
import { d as readSessionEntryRow } from "./session-accessor.sqlite-entry-read-69RuwSjJ.mjs";
import { c as publishSessionEntryWorkerMetadataInvalidation, d as publishSessionSharingMemberChange, r as bindSessionEntryPublicationSource } from "./session-accessor.sqlite-entry-cache-publication-B13oEfaQ.mjs";
import { n as emitSessionLifecycleEvent } from "./session-lifecycle-events-CfTrpgyR.mjs";
import { o as publishCommittedSessionIdentity } from "./session-accessor.sqlite-identity-BZB1295A.mjs";
import { i as captureIncognitoSessionSource, n as captureIncognitoSessionHistoryBinding, r as captureIncognitoSessionOperation } from "./session-incognito-binding-Dp6RTei2.mjs";
import { a as waitForPreparedSessionTranscriptProjection, i as startSessionTranscriptIndexReconcile, l as prepareReconcileParams, n as reconcileSessionTranscriptIndexes, r as startPreparedSessionTranscriptIndexReconcile } from "./session-transcript-reconcile-BwrFIOby.mjs";
import { n as publishSessionEntryCacheInvalidation } from "./session-accessor.sqlite-entry-cache-COU_r18s.mjs";
import { n as retainSessionEntryWorkerPublication } from "./session-accessor.sqlite-entry-worker-publication-BNeFwCVE.mjs";
import { c as withSessionHistoryWorkerDatabase } from "./session-transcript-worker-runtime-BdmdicNg.mjs";
import { n as assertSessionTranscriptHot, t as SessionTranscriptColdError } from "./session-cold-storage-state-BRw-PqQq.mjs";
import { l as readTranscriptGenerationInTransaction } from "./session-accessor.sqlite-transcript-state-AbdQy_JW.mjs";
import "./session-accessor.sqlite-entry-store-CIM2yoGL.mjs";
import { _ as runWithSessionPendingInput, c as parseSessionPendingInputMessage, h as releaseSessionPendingInputOwner, l as prepareCurrentSessionPendingInputDedupeRecovery, m as registerSessionPendingInputOwner, n as assertSessionPendingInputLifetimeCurrent, o as hasRegisteredSessionPendingInputOwner, s as isFinalInputCompletion, t as assertRegisteredSessionPendingInputOwner, v as runWithSessionPendingInputPersistence } from "./session-accessor.sqlite-pending-inputs-KrOcYFST.mjs";
import "./session-accessor.sqlite-owner-BqW6gmHA.mjs";
import { a as updatePreparedSessionProfileInvolvement, n as removeSessionMember, r as recordSessionParticipant, t as addSessionMember } from "./session-sharing-store.native-DO4w6Chl.mjs";
import "./session-accessor.sqlite-active-events-Zkd0MAwt.mjs";
import "./session-accessor.sqlite-transcript-anchor-VJSh_9H1.mjs";
import { t as readMessageIdempotencyKey } from "./transcript-message-identity-0wQEn3Eb.mjs";
import "./session-accessor.sqlite-model-context-C4SiIif1.mjs";
import "./session-accessor.sqlite-transcript-watermark-C7PwEdqC.mjs";
import { d as rewriteSqliteTranscriptEventRowsInTransaction, l as redactTranscriptMessageForStorage } from "./session-accessor.sqlite-transcript-store-D63Niwm2.mjs";
import { n as readRestoredSessionTranscript } from "./session-cold-storage-read-Dq7uoWUT.mjs";
import { n as hasSessionTranscriptMessageInDatabase } from "./session-accessor.sqlite-transcript-metadata-read-CcCcTKgR.mjs";
import { i as findTranscriptEventInDatabase, w as readTranscriptStatsSync, x as readTranscriptIdentityByEventId } from "./session-accessor.sqlite-read-UBWmiUlC.mjs";
import { a as readSessionBranchSnapshot, i as readCachedSessionBranchSummaries, n as cloneSessionBranchSummaries, t as cacheSessionBranchSummaries } from "./session-accessor.sqlite-branches-DbNeIw74.mjs";
import { t as readSessionTranscriptHotWatermark } from "./session-accessor.sqlite-transcript-watermark-read-D2nLMbB0.mjs";
import "./session-accessor.sqlite-message-cut-B3ojJIIO.mjs";
import { a as withSessionEntryWorker, r as prepareSessionEntryReplacementDatabase } from "./session-accessor.sqlite-replacement-worker-vT9ZZh6F.mjs";
import { t as captureSessionStoreReadCandidates } from "./session-store-target-inventory-C9ERDnSH.mjs";
import { n as runSessionEntryWorkerOperation } from "./session-entry-patch-fXJDvWHG.mjs";
import { n as readIncognitoSessionHistory } from "./session-incognito-history-read-BhWdcIgY.mjs";
import "./session-transcript-events-IicO6BRV.mjs";
import "./session-transcript-maintenance-read-BjORo8zl.mjs";
import { t as withSessionTranscriptReadSource } from "./session-transcript-read-source-V0JvL2x_.mjs";
import { n as prepareTranscriptMessageAppend } from "./session-accessor.sqlite-transcript-message-append-BJ-UFuvo.mjs";
import { n as readCommittedTranscriptMessageSequence, r as rememberCommittedTranscriptMessageSequences } from "./session-accessor.sqlite-transcript-sequences-7rgFBxQf.mjs";
import { i as resolveTranscriptAppendRefusal } from "./session-accessor.sqlite-transcript-write-guard-B9tPlUJx.mjs";
import { t as selectManualCompactTranscriptLines } from "./session-manual-compact-selection-Durlxhuz.mjs";
import { _ as captureSessionManagerIncognitoBinding, i as appendTranscriptMessage } from "./session-accessor.sqlite-transcript-write-ClP59_lJ.mjs";
import "./session-accessor.sqlite-history-BHbnFYFh.mjs";
import { n as publishTranscriptUpdate } from "./session-accessor.sqlite-events-x56_8OQX.mjs";
import "./session-accessor.sqlite-entry-DLa7_9ui.mjs";
import { a as persistCompactionBoundaryWithSessionEntrySync, o as trimTranscriptForManualCompact } from "./session-accessor.sqlite-metadata-read-BzhXpz0y.mjs";
import { t as applyAssistantDeliveryDirectives } from "./transcript-assistant-delivery-CGqOQ0cS.mjs";
import { a as prepareTranscriptReportSelection, i as prepareCustomTranscriptReport, r as appendSessionTranscriptReportInTransaction, t as appendAbortedSessionTranscriptPartialInTransaction } from "./session-accessor.sqlite-transcript-reports.kernel-Mo5MHvdq.mjs";
import "./session-accessor.sqlite-pending-input-receipts-vPi1_tfk.mjs";
import "./server-constants-BH_EolwD.mjs";
import { t as withCurrentPendingInputAuthority } from "./session-pending-input-authority-CoXHTQsM.mjs";
import "./session-pending-input-history-DHrvjo_s.mjs";
import "./session-entry-read-runtime-BdnQjoL6.mjs";
import "./session-accessor.entry-xtqpYxWo.mjs";
import "./session-accessor.sqlite-entry-availability-DMY31I3P.mjs";
import { l as updateSessionEntry } from "./session-accessor.entry-mutation-telsi3Ig.mjs";
import "./session-accessor.reset-CptYK9cG.mjs";
import { t as executeSessionMessageRewriteOperation } from "./session-message-rewrite-domain-Ll8GY8i_.mjs";
import { i as resolveSessionWorkStartError } from "./session-work-start-Bkld8CTK.mjs";
import { i as receiveSessionManagerCommit, t as SessionEntryCommittedError } from "./session-manager-persistence-error-BRf57HJz.mjs";
import "./session-accessor.sqlite-delta-BqCrHWS1.mjs";
import "./session-transcript-match-DM9H8_yA.mjs";
import { n as completeSessionTranscriptCommit, t as appendExpectedSessionTranscriptTurn } from "./session-accessor.sqlite-transcript-turn-_T1DVPZi.mjs";
import { o as resolveSessionTranscriptRuntimeTarget } from "./session-accessor.transcript-target-DdAdqCJ1.mjs";
import "./session-accessor.sqlite-participant-read-czr1DN8h.mjs";
import path from "node:path";
import { isDeepStrictEqual, toUSVString } from "node:util";
import { createHash, randomUUID } from "node:crypto";
//#region src/config/sessions/session-transcript-projection-recovery.ts
/** Rebuilds a newly admitted session on its prepared physical store, then waits there. */
async function recoverSessionTranscriptProjection(scope, abortSignal, assertCurrent) {
	abortSignal.throwIfAborted();
	const resolved = await prepareSqliteTranscriptReadScope(scope, abortSignal);
	assertCurrent();
	abortSignal.throwIfAborted();
	const prepared = prepareReconcileParams({
		...toDatabaseOptions(resolved),
		preferredSessionId: resolved.sessionId
	});
	startPreparedSessionTranscriptIndexReconcile(prepared);
	const wait = () => waitForPreparedSessionTranscriptProjection(resolved.sessionId, prepared, abortSignal);
	await (prepared.incognito ? prepared.incognito.actor.sessions.withSharedState(wait) : wait());
}
//#endregion
//#region src/chat/message-client-source.ts
function messageClientSourcesKey(sources) {
	return JSON.stringify(sources.map(({ id, mode, displayName }) => [
		id,
		mode,
		displayName ?? null
	]));
}
function normalizeMessageClientSources(value) {
	if (!Array.isArray(value)) return [];
	const sources = /* @__PURE__ */ new Map();
	for (const item of value) {
		const record = asOptionalRecord(item);
		const id = normalizeGatewayClientId(typeof record?.id === "string" ? record.id : void 0);
		const mode = normalizeGatewayClientMode(typeof record?.mode === "string" ? record.mode : void 0);
		if (!id || !mode) continue;
		const name = normalizeOptionalString(record?.displayName);
		const source = {
			id,
			mode,
			...name ? { displayName: truncateUtf16Safe(name, 200) } : {}
		};
		sources.set(messageClientSourcesKey([source]), source);
	}
	return [...sources.values()];
}
function readMessageClientSources(message) {
	const metadata = asOptionalRecord(asOptionalRecord(message)?.["__openclaw"]);
	return normalizeMessageClientSources(asOptionalRecord(metadata?.transport)?.clients);
}
//#endregion
//#region src/config/sessions/session-accessor.pending-input-request.ts
function resolvePendingInputRequestHash(message, requestFingerprint) {
	return requestFingerprint ? `request:${requestFingerprint}` : sha256Hex(stableStringify(message));
}
function preparePendingInputMessage(message, requestFingerprint) {
	const { timestamp: _timestamp, ...stableMessage } = message;
	if (Buffer.byteLength(JSON.stringify(stableMessage), "utf8") > 26214400) throw new Error("Pending input exceeds the Gateway payload limit");
	return {
		stableMessage,
		requestHash: resolvePendingInputRequestHash(stableMessage, requestFingerprint)
	};
}
function preparePendingInputRequest(params) {
	const idempotencyKey = readMessageIdempotencyKey(params.message);
	if (!idempotencyKey || !params.runId) throw new Error("Pending input requires an exact run and message idempotency key");
	return {
		message: params.message,
		runId: params.runId,
		idempotencyKey,
		replaySourceSessionKeys: params.replaySourceSessionKeys,
		...preparePendingInputMessage(params.message, params.requestFingerprint)
	};
}
/** Reconcile only a shipped scheduling-source variation against its complete accepted hash. */
function resolvePendingInputReplayRequest(prepared, accepted) {
	const { message, replaySourceSessionKeys } = prepared;
	const original = {
		message,
		stableMessage: prepared.stableMessage,
		requestHash: prepared.requestHash
	};
	if (!replaySourceSessionKeys) return original;
	if (prepared.requestHash.startsWith("request:") || message.provenance?.kind !== "inter_session" || message.provenance.sourceTool !== "subagent_settle") throw new Error("Pending input source replay requires an internal settle request");
	if (accepted?.run_id !== prepared.runId || accepted.request_hash === prepared.requestHash) return original;
	for (const sourceSessionKey of new Set(replaySourceSessionKeys)) {
		const candidate = {
			...message,
			provenance: {
				...message.provenance,
				sourceSessionKey
			}
		};
		const request = preparePendingInputMessage(candidate);
		if (request.requestHash === accepted.request_hash) return {
			message: candidate,
			...request
		};
	}
	return original;
}
/** Prove committed private input by its approved bytes, while hashing the raw retry. */
function resolveCommittedPendingInputRequestHash(options, committedMessage) {
	let candidate = preparePendingInputRequest(options);
	if (options.replaySourceSessionKeys) {
		if (candidate.idempotencyKey !== `${options.runId}:user`) throw new Error("Input completion retry conflicts with the accepted run");
		const committedProvenance = committedMessage.provenance;
		const sourceSessionKey = committedProvenance?.sourceSessionKey;
		if (!options.message.provenance || committedProvenance?.kind !== "inter_session" || committedProvenance.sourceTool !== "subagent_settle" || !sourceSessionKey || !options.replaySourceSessionKeys.includes(sourceSessionKey)) throw new Error("Input completion committed source is outside the frozen settle cohort");
		candidate = preparePendingInputRequest({
			...options,
			message: {
				...options.message,
				provenance: {
					...options.message.provenance,
					sourceSessionKey
				}
			}
		});
	}
	const prepared = options.prepareMessageAfterIdempotencyCheck ? options.prepareMessageAfterIdempotencyCheck(candidate.message) : candidate.message;
	if (!prepared) return;
	const { timestamp: _preparedTimestamp, ...stablePrepared } = redactTranscriptMessageForStorage(prepared, { config: options.config });
	const { timestamp: _committedTimestamp, ...stableCommitted } = committedMessage;
	if (stableStringify(stablePrepared) !== stableStringify(stableCommitted)) throw new Error("Input completion retry conflicts with the committed input");
	return candidate.requestHash;
}
function matchesSessionPendingInputRequest(receipt, message, requestHash) {
	if (receipt.request_hash === requestHash) return true;
	if (receipt.consumed_event_id == null) return false;
	if (receipt.request_hash === resolvePendingInputRequestHash(message)) return true;
	const metadata = asOptionalRecord(message["__openclaw"]);
	const transport = asOptionalRecord(metadata?.transport);
	if (!metadata || !transport || !Object.hasOwn(transport, "clients")) return false;
	const legacyTransport = { ...transport };
	delete legacyTransport.clients;
	const legacyMetadata = { ...metadata };
	if (Object.keys(legacyTransport).length) legacyMetadata.transport = legacyTransport;
	else delete legacyMetadata.transport;
	const legacyMessage = { ...message };
	if (Object.keys(legacyMetadata).length) legacyMessage["__openclaw"] = legacyMetadata;
	else delete legacyMessage["__openclaw"];
	return receipt.request_hash === resolvePendingInputRequestHash(legacyMessage);
}
//#endregion
//#region src/config/sessions/session-pending-input-source.ts
async function readPendingInputSource(scope, idempotencyKey, pendingOnly) {
	const captured = {
		...scope,
		incognito: scope.incognito ?? captureIncognitoSessionOperation(scope),
		env: captureSessionTranscriptStorageEnvironment(scope.env ?? process.env)
	};
	const logical = resolveSqliteScope({
		...captured,
		storePath: void 0
	});
	const input = {
		kind: "source",
		sessionKey: logical.sessionKey,
		sessionId: captured.sessionId,
		idempotencyKey,
		pendingOnly
	};
	if (captured.incognito) {
		const { actor, authority } = captured.incognito;
		actor.assertCurrent();
		authority.assertCurrent();
		if (!isIncognitoSessionKey(logical.sessionKey) || actor.agentId !== logical.agentId || actor.path !== resolveOpenClawAgentSqlitePath(toDatabaseOptions(logical))) throw new Error("Submitted input target differs from its captured incognito actor");
		const claim = actor.sessions.captureCurrent(logical.sessionKey);
		const assertCurrent = () => {
			actor.assertCurrent();
			actor.assertReadable();
			authority.assertCurrent();
			claim.assertCurrent();
		};
		const snapshot = await actor.sessions.readPendingInput({
			assertCurrent,
			authorize: (stage, facts) => authority.authorize?.(stage, facts)
		}, input);
		assertCurrent();
		if (snapshot.kind !== "source") throw new Error("Submitted input returned a different operation");
		return {
			path: actor.path,
			snapshot,
			assertCurrent
		};
	}
	if (isIncognitoSessionKey(captured.sessionKey)) {
		const options = toDatabaseOptions(resolveSqliteScope(captured));
		const database = getOpenClawAgentDatabaseIfOpen(options);
		if (!database) return;
		const assertCurrent = () => {
			if (getOpenClawAgentDatabaseIfOpen(options) !== database || !database.db.isOpen) throw new Error("Submitted input lost its incognito database owner");
		};
		const { readPendingInputSourceInDatabase } = await import("./session-pending-input-source.kernel-C9kUtd6q.mjs");
		assertCurrent();
		return {
			path: database.path,
			snapshot: readPendingInputSourceInDatabase(database, input),
			assertCurrent
		};
	}
	const storePath = logical.path ?? captured.storePath ?? resolveOpenClawAgentSqlitePath(toDatabaseOptions(logical));
	const candidates = captureSessionStoreReadCandidates(storePath);
	const identities = captureSessionStoreCandidateIdentities(candidates);
	const resolved = await prepareSqliteScope(captured);
	const options = toDatabaseOptions(resolved);
	const path = resolveOpenClawAgentSqlitePath(options);
	const identity = identities.get(assertSessionStoreReadCandidate(path, candidates));
	if (!identity) throw new Error("Submitted input changed its captured database owner");
	if (!identity.key.startsWith("file:")) return;
	const assertCurrent = () => {
		assertSessionStoreReadCandidate(path, candidates);
		assertExistingDatabaseIdentity(path, identity.key, identity.birthtime);
	};
	assertCurrent();
	const snapshot = await withSessionHistoryWorkerDatabase({
		...options,
		path
	}, (owner) => owner.readPendingInputSource({
		input: {
			...input,
			sessionKey: resolved.sessionKey
		},
		env: captured.env,
		source: {
			agentId: options.agentId,
			path,
			databaseIdentity: identity.key.slice(5),
			databaseBirthtime: identity.birthtime
		}
	}));
	assertCurrent();
	return {
		path: identity.canonicalPath,
		snapshot,
		assertCurrent
	};
}
//#endregion
//#region src/config/sessions/session-pending-input-store.ts
async function preparePendingInputStore(scope, assertCurrent) {
	const captured = {
		...scope,
		incognito: scope.incognito ?? captureIncognitoSessionOperation(scope),
		env: captureSessionTranscriptStorageEnvironment(scope.env ?? process.env)
	};
	const incognito = isIncognitoSessionKey(captured.sessionKey);
	const logical = resolveSqliteScope({
		...captured,
		storePath: void 0
	});
	const binding = captured.incognito && { ...captured.incognito };
	const actor = binding?.actor;
	if (actor && binding) {
		actor.assertCurrent();
		binding.authority.assertCurrent();
		if (!incognito || actor.agentId !== logical.agentId || actor.path !== resolveOpenClawAgentSqlitePath(toDatabaseOptions(logical))) throw new Error("Pending input target differs from its captured incognito actor");
	}
	const storePath = logical.path ?? captured.storePath ?? resolveOpenClawAgentSqlitePath(toDatabaseOptions(logical));
	const candidates = incognito ? [] : captureSessionStoreReadCandidates(storePath);
	const identities = captureSessionStoreCandidateIdentities(candidates);
	const resolved = actor ? resolveSqliteScope(captured) : await prepareSqliteScope(captured);
	assertCurrent();
	const options = {
		...toDatabaseOptions(resolved),
		path: resolveOpenClawAgentSqlitePath(toDatabaseOptions(resolved))
	};
	const identity = incognito ? void 0 : identities.get(assertSessionStoreReadCandidate(options.path, candidates));
	if (!incognito && (!identity || !identity.key.startsWith("file:"))) throw new Error("Pending input changed its captured database owner");
	const assertSource = () => {
		actor?.assertCurrent();
		if (identity) {
			assertSessionStoreReadCandidate(options.path, candidates);
			assertExistingDatabaseIdentity(options.path, identity.key, identity.birthtime);
		}
	};
	const { readPendingInput, mutatePendingInput } = await import("./session-pending-input-operations.kernel-CNdkgTMV.mjs");
	assertSource();
	let revoked = false;
	let revokeCustody = () => {};
	const pending = /* @__PURE__ */ new Set();
	const failures = [];
	const drain = async () => {
		while (pending.size) await Promise.allSettled(pending);
	};
	const settled = async () => {
		await drain();
		if (failures.length) throw failures[0];
	};
	const unregister = registerOpenClawAgentDatabaseAsyncResource({
		agentId: options.agentId ?? resolved.agentId,
		path: options.path,
		revoke() {
			revoked = true;
			revokeCustody();
		},
		close: drain
	});
	const assertOpen = () => {
		if (revoked) throw new Error("Pending input database owner has closed");
		assertSource();
	};
	const track = (operation) => {
		pending.add(operation);
		operation.then(() => pending.delete(operation), (error) => {
			failures.push(error);
			pending.delete(operation);
		});
		return operation;
	};
	const nativeMutation = (input, guard) => {
		assertOpen();
		if (actor) throw new IncognitoSessionSyncAccessError("complete", "completeAsync");
		return mutatePendingInput(input, {
			admit: (stage, facts) => {
				assertOpen();
				guard(stage, facts);
			},
			writeTransaction: (operationLabel, _owner, run) => runOpenClawAgentWriteTransaction(run, options, { operationLabel })
		}, () => {});
	};
	return {
		assertCurrent: assertOpen,
		withAdmission(operation, reentrant) {
			let entered = false;
			const run = () => runOpenClawAgentWriteAdmission(options, () => {
				entered = true;
				return operation();
			}, reentrant).catch((error) => {
				if (!entered) unregister();
				throw error;
			});
			return actor ? actor.sessions.withSharedState(run) : run();
		},
		sessionKey: resolved.sessionKey,
		databaseAgentId: options.agentId ?? resolved.agentId,
		path: options.path,
		workerDatabasePath: identity?.canonicalPath ?? options.path,
		bindCustody(revoke) {
			revokeCustody = revoke;
		},
		settled,
		retire(operation) {
			track(operation);
			operation.then(unregister, (error) => {
				if (!hasSqliteWorkerOutcomeUnknown(error)) unregister();
			});
		},
		async release() {
			try {
				await settled();
			} finally {
				unregister();
			}
		},
		read(input) {
			return track((async () => {
				assertOpen();
				assertCurrent();
				if (actor && binding) return actor.sessions.readPendingInput({
					assertCurrent: () => {
						assertOpen();
						assertCurrent();
						binding.authority.assertCurrent();
					},
					authorize: (stage, facts) => binding.authority.authorize?.(stage, facts)
				}, input);
				if (incognito) return readPendingInput(openOpenClawAgentDatabase(options), input);
				return withSessionEntryWorker(options, identity?.key.slice(5), () => {
					assertOpen();
					assertCurrent();
				}, async (execution, source) => {
					const result = await execution.runExisting(source, (worker) => worker.execute({
						type: "session.pendingInputs.read",
						input
					}));
					if (!result) throw new Error("Pending input lost its existing database");
					return result;
				});
			})());
		},
		nativeMutation,
		mutate(input, guard, publish) {
			return track((async () => {
				assertOpen();
				if (actor && binding) {
					let committedFacts;
					return actor.sessions.mutatePendingInput({
						assertCurrent: () => {
							assertOpen();
							binding.authority.assertCurrent();
						},
						authorize: (stage, facts) => binding.authority.authorize?.(stage, facts)
					}, input, (stage, facts) => {
						committedFacts = facts;
						guard(stage, facts);
					}, publish ? () => publish(committedFacts, assertOpen) : void 0);
				}
				if (incognito) {
					let committedFacts;
					const result = nativeMutation(input, (stage, facts) => {
						committedFacts = facts;
						guard(stage, facts);
					});
					publish?.(committedFacts, assertOpen);
					return result;
				}
				let admitted;
				const readReceipt = (facts) => readPendingInputMutationReceipt(facts, input);
				let committedFacts;
				const checkGrant = (stage, facts) => {
					if (!isRecord(facts) || !isRecord(facts.publication) || facts.publication.kind !== "pending-input-settlement-custody") return;
					committedFacts = facts.publication;
					guard(stage, committedFacts);
				};
				return withSessionEntryWorker(options, identity?.key.slice(5), assertOpen, async (execution, source, context) => {
					const result = await execution.runExisting(source, async (worker) => {
						const native = getOpenClawAgentDatabaseIfOpen(options);
						const revision = native && readSqliteNativeMutationRevision(native.db);
						const assertPublicationCurrent = () => {
							context.assertCurrent();
							if (getOpenClawAgentDatabaseIfOpen(options) !== native || native && (native.db.isTransaction || revision === void 0 || readSqliteNativeMutationRevision(native.db) !== revision)) throw new Error("Pending input authority changed before publication");
						};
						const outcome = await worker.execute({
							type: "session.pendingInputs.mutate",
							input
						}).then((value) => ({
							ok: true,
							value
						}), (error) => ({
							ok: false,
							error
						}));
						if (admitted) {
							await admitted.retained.settled;
							const receipt = readReceipt(admitted.admission.committed?.facts);
							if (admitted.admission.settlement?.kind === "completed" && receipt) {
								if (publish) assertOpen();
								if (publish) {
									assertPublicationCurrent();
									publish(committedFacts, assertPublicationCurrent);
								}
								return receipt;
							}
							if (admitted.admission.settlement?.kind !== "completed") throw new SqliteWorkerError("Pending input native commitment is unknown; do not replay", "outcome-unknown");
						}
						if (!outcome.ok) throw outcome.error;
						throw new SqliteWorkerError("Pending input has no confirmed native completion and commit receipt", "outcome-unknown");
					});
					if (!result) throw new Error("Pending input lost its existing database");
					return result;
				}, (admission, retained, facts) => {
					checkGrant("commit", facts);
					if (!isRecord(facts) || !isRecord(facts.publication) || !readReceipt(facts.publication.receipt)) throw new Error("Pending input commit omitted its exact receipt");
					admitted = {
						admission,
						retained
					};
				}, void 0, void 0, void 0, (facts) => checkGrant("transaction", facts));
			})());
		}
	};
}
//#endregion
//#region src/config/sessions/session-accessor.pending-inputs.ts
const receiptOwners = /* @__PURE__ */ new WeakMap();
const withdrawnOwners = /* @__PURE__ */ new WeakSet();
function readWithdrawnSessionPendingInputId(receipt) {
	const owner = receipt && receiptOwners.get(receipt);
	return owner && withdrawnOwners.has(owner) ? owner.inputId : void 0;
}
function ownerReceipt(owner) {
	const receipt = {
		get state() {
			return owner.consumed || owner.sources?.every((source) => source.consumed) ? "consumed" : "queued";
		},
		inputId: owner.inputId,
		message: parseSessionPendingInputMessage(owner.messageJson),
		run: (operation) => runWithSessionPendingInput(owner, operation),
		runAsync: (operation) => withCurrentPendingInputAuthority((owner.sources ?? [owner]).flatMap((source) => source.authority ? [source.authority] : []), () => assertSessionPendingInputLifetimeCurrent(owner), () => runWithSessionPendingInput(owner, operation)),
		assertLifetimeCurrent: () => assertSessionPendingInputLifetimeCurrent(owner),
		finish: owner.finish
	};
	receiptOwners.set(receipt, owner);
	return receipt;
}
/** Install only a private receipt's persistence context; this does not reopen execution authority. */
function withSessionPendingInputPersistence(receipt, persist) {
	const owner = receiptOwners.get(receipt);
	return owner ? runWithSessionPendingInputPersistence(owner, persist) : receipt.run(persist);
}
/** Bind one collected message to its private admitted sources without creating another durable queue. */
function bindSessionPendingInputSources(receipts, message) {
	const sources = [...new Set(receipts.flatMap((receipt) => {
		if (receipt.state === "consumed") throw new Error("Collected input has already been consumed");
		const owner = receiptOwners.get(receipt);
		return owner ? owner.sources ?? [owner] : [];
	}))];
	const first = sources[0];
	if (!first) return;
	const idempotencyKey = readMessageIdempotencyKey(message);
	if (!idempotencyKey || sources.some((source) => source.workerDatabasePath !== first.workerDatabasePath || source.sessionId !== first.sessionId || source.sessionKey !== first.sessionKey || source.idempotencyKey === idempotencyKey)) throw new Error("Collected input requires one exact session and a distinct aggregate identity");
	const clients = normalizeMessageClientSources(receipts.flatMap((receipt) => readMessageClientSources(receipt.message)));
	const collectedMessage = { ...message };
	if (clients.length) collectedMessage["__openclaw"] = {
		...message["__openclaw"],
		transport: {
			...asOptionalRecord(message["__openclaw"]?.transport),
			clients
		}
	};
	const messageJson = JSON.stringify(redactTranscriptMessageForStorage(collectedMessage, { config: sources.at(-1)?.config }));
	if (Buffer.byteLength(messageJson, "utf8") > 26214400) throw new Error("Collected input exceeds the Gateway payload limit");
	const aggregateInputId = randomUUID();
	const aggregate = ownerReceipt({
		...first,
		inputId: aggregateInputId,
		transcriptInputId: aggregateInputId,
		idempotencyKey,
		messageJson,
		sources,
		finish: (disposition) => {
			const failures = [];
			for (const source of sources) try {
				source.finish(disposition);
			} catch (error) {
				failures.push(error);
			}
			if (failures.length) throw new AggregateError(failures, "Failed to finish collected input custody");
		}
	});
	aggregate.settled = async () => {
		const failures = (await Promise.allSettled(receipts.map(async (receipt) => receipt.settled?.()))).flatMap((result) => result.status === "rejected" ? [result.reason] : []);
		if (failures.length === 1) throw failures[0];
		if (failures.length) throw new AggregateError(failures, "Failed to settle collected input custody");
	};
	return aggregate;
}
/** Accept durable input without changing the active transcript or scheduling execution. */
function stageSessionPendingInput(scope, options) {
	const incognito = scope.incognito ?? captureIncognitoSessionOperation(scope);
	incognito?.admissionSignal?.throwIfAborted();
	incognito?.actor.assertCurrent();
	const captured = {
		...scope,
		incognito: incognito && { ...incognito },
		env: captureSessionTranscriptStorageEnvironment(scope.env ?? process.env)
	};
	const preparedRequest = preparePendingInputRequest(options);
	const lifecycleGeneration = getAgentEventLifecycleGeneration();
	const ownAdmissions = options.authority !== void 0 && !incognito && !isIncognitoSessionKey(captured.sessionKey);
	const admission = ownAdmissions ? void 0 : resolveSqliteWriteAdmissionScope(captured);
	const stage = async () => {
		const store = await preparePendingInputStore(captured, options.authority?.assertLifetimeCurrent ?? options.assertCurrent);
		const accept = () => stagePreparedPendingInput(captured, options, preparedRequest, lifecycleGeneration, store);
		return ownAdmissions ? accept() : store.withAdmission(accept, admission !== void 0);
	};
	return admission ? runOpenClawAgentWriteAdmission(toDatabaseOptions(admission), stage) : stage();
}
async function stagePreparedPendingInput(scope, options, preparedRequest, lifecycleGeneration, store) {
	let retained = false;
	let finished = false;
	let owner;
	let completion;
	const assertPrepared = (facts, guard, assertSourceCurrent = store.assertCurrent) => {
		if (options.authority) {
			if (!facts?.authority) throw new Error("Pending input grant omitted its current session authority");
			return options.authority.withPreparedCurrent(facts.authority, guard, assertSourceCurrent);
		}
		return guard();
	};
	const assertCurrent = () => options.authority ? options.authority.withCurrent(() => options.assertCurrent()) : options.assertCurrent();
	try {
		const identity = {
			sessionKey: store.sessionKey,
			sessionId: scope.sessionId,
			idempotencyKey: preparedRequest.idempotencyKey
		};
		const snapshot = await store.read({
			...identity,
			kind: "stage",
			trackCompletion: options.trackCompletion === true
		});
		if (snapshot.kind !== "stage") throw new Error("Pending input read returned a different operation");
		await assertCurrent();
		assertAgentRunLifecycleGenerationCurrent(lifecycleGeneration);
		if (!snapshot.current) return;
		const { existing, previous, committed } = snapshot;
		const replayRequest = resolvePendingInputReplayRequest(preparedRequest, previous ?? existing);
		const { message, stableMessage } = replayRequest;
		let requestHash = replayRequest.requestHash;
		if (previous && (previous.request_hash !== requestHash || previous.run_id !== options.runId)) throw new Error("Input completion idempotency key conflicts with the accepted input");
		if (previous && isFinalInputCompletion(previous.outcome)) return {
			state: "consumed",
			inputId: identity.idempotencyKey,
			message,
			completion: previous.outcome,
			run: () => {
				throw new Error("Input processing has already completed");
			},
			finish: () => {}
		};
		const assertUnowned = (row = existing) => {
			if (row && hasRegisteredSessionPendingInputOwner(store.workerDatabasePath, row)) throw new SessionPendingInputCustodyError("Pending input is already admitted; wait for its current turn");
		};
		if (existing) {
			if (!matchesSessionPendingInputRequest(existing, stableMessage, requestHash) || existing.run_id !== options.runId) throw new Error("Pending input idempotency key conflicts with the accepted input");
			if (existing.consumed_event_id != null) return {
				state: "consumed",
				inputId: existing.input_id,
				message: parseSessionPendingInputMessage(existing.message_json),
				run: () => {
					throw new Error("Pending input has already been consumed");
				},
				finish: () => {}
			};
			assertUnowned();
			if (!options.requestFingerprint && !options.trackCompletion || existing.state !== "queued" && existing.state !== "interrupted" || existing.lifecycle_generation === lifecycleGeneration && !options.trackCompletion) throw new Error("Pending input ownership ended; submit a new turn to continue");
		}
		const settlementIdentity = () => ({
			...identity,
			runId: options.runId,
			requestHash,
			lifecycleGeneration,
			...options.authority ? { authorityAgentId: scope.agentId } : {}
		});
		const assertCompletion = () => {
			(options.assertCompletionCurrent ?? options.assertCurrent)();
			assertAgentRunLifecycleGenerationCurrent(lifecycleGeneration);
			if (owner) assertRegisteredSessionPendingInputOwner(owner);
		};
		const completionInput = (outcome) => ({
			...settlementIdentity(),
			kind: "complete",
			outcome
		});
		const complete = options.trackCompletion ? (outcome) => {
			if (finished || completion) throw new Error("Input completion owner has already been released or is settling");
			assertCompletion();
			return store.nativeMutation(completionInput(outcome), assertCompletion).outcome;
		} : void 0;
		const completeAsync = options.trackCompletion ? (outcome) => {
			if (completion) return completion;
			if (finished) return Promise.reject(/* @__PURE__ */ new Error("Input completion owner has already been released"));
			(options.authority?.assertLifetimeCurrent ?? assertCompletion)();
			completion = store.mutate(completionInput(outcome), (_stage, facts) => assertPrepared(facts, assertCompletion)).then((receipt) => {
				if (!receipt.outcome) throw new Error("Input completion omitted its committed outcome");
				return receipt.outcome;
			});
			return completion;
		} : void 0;
		const finish = (disposition) => {
			if (finished) return;
			finished = true;
			if (owner) owner.settling = true;
			const settleDisposition = async () => {
				if (owner && !owner.consumed) {
					if ((await store.mutate({
						...settlementIdentity(),
						kind: "finish",
						inputId: owner.inputId,
						disposition
					}, () => assertRegisteredSessionPendingInputOwner(owner))).withdrawnInputId === owner.inputId) withdrawnOwners.add(owner);
				}
			};
			const ending = completion ? completion.catch((error) => {
				rethrowIncognitoSessionError(error);
				if (hasSqliteWorkerOutcomeUnknown(error)) throw error;
			}).then(settleDisposition) : settleDisposition();
			store.retire(ending.then(() => {
				if (owner) releaseSessionPendingInputOwner(owner);
			}, (error) => {
				if (owner && !hasSqliteWorkerOutcomeUnknown(error)) releaseSessionPendingInputOwner(owner);
				throw error;
			}));
		};
		store.bindCustody(() => {
			finished = true;
			if (owner) releaseSessionPendingInputOwner(owner);
		});
		const completionMethods = {
			...complete ? {
				complete,
				completeAsync
			} : {},
			settled: store.settled
		};
		if (committed) {
			if (options.trackCompletion) {
				const committedHash = resolveCommittedPendingInputRequestHash({
					...options,
					message,
					replaySourceSessionKeys: previous || existing ? void 0 : options.replaySourceSessionKeys
				}, committed.message);
				if (!committedHash) return;
				requestHash = committedHash;
				await assertCurrent();
			}
			retained = true;
			const run = (operation) => {
				store.assertCurrent();
				if (finished) throw new SessionPendingInputCustodyError("Pending input ownership ended");
				scope.incognito?.authority.assertCurrent();
				options.assertCurrent();
				return operation();
			};
			return {
				state: "queued",
				inputId: committed.messageId,
				message: committed.message,
				run,
				assertLifetimeCurrent: () => {
					store.assertCurrent();
					(options.authority?.assertLifetimeCurrent ?? options.assertCurrent)();
				},
				runAsync: (operation) => withCurrentPendingInputAuthority(options.authority ? [options.authority] : [], () => {
					store.assertCurrent();
					options.authority?.assertLifetimeCurrent();
				}, () => run(operation)),
				finish,
				...completionMethods
			};
		}
		const prepareMessage = () => {
			options.assertCurrent();
			return options.prepareMessageAfterIdempotencyCheck(message);
		};
		const prepared = existing ? parseSessionPendingInputMessage(existing.message_json) : options.prepareMessageAfterIdempotencyCheck ? options.authority ? await options.authority.withCurrent(prepareMessage) : prepareMessage() : message;
		if (!prepared) return;
		const messageJson = existing?.message_json ?? JSON.stringify(redactTranscriptMessageForStorage(prepared, { config: options.config }));
		if (Buffer.byteLength(messageJson, "utf8") > 26214400) throw new Error("Approved pending input exceeds the Gateway payload limit");
		const inputId = existing?.input_id ?? randomUUID();
		const assertAdmittedCurrent = options.assertAdmittedCurrent ?? options.assertCurrent;
		owner = {
			agentId: scope.agentId,
			databaseAgentId: store.databaseAgentId,
			inputId,
			transcriptInputId: inputId,
			sessionId: scope.sessionId,
			sessionKey: store.sessionKey,
			databasePath: store.path,
			workerDatabasePath: store.workerDatabasePath,
			idempotencyKey: identity.idempotencyKey,
			lifecycleGeneration,
			messageJson,
			config: options.config,
			assertCurrent: () => {
				store.assertCurrent();
				scope.incognito?.actor.assertCurrent();
				scope.incognito?.authority.assertCurrent();
				assertAdmittedCurrent();
			},
			authority: options.authority,
			...existing ? { restartRecovered: true } : {},
			finish
		};
		await store.mutate({
			...settlementIdentity(),
			kind: "stage",
			expected: snapshot,
			trackCompletion: options.trackCompletion === true,
			inputId,
			messageJson
		}, (_stage, facts) => {
			assertPrepared(facts, () => {
				options.assertCurrent();
				assertAgentRunLifecycleGenerationCurrent(lifecycleGeneration);
				assertUnowned(facts?.candidate);
			});
		}, (facts, assertSourceCurrent) => {
			assertPrepared(facts, () => {
				options.assertCurrent();
				assertAgentRunLifecycleGenerationCurrent(lifecycleGeneration);
				registerSessionPendingInputOwner(owner);
			}, assertSourceCurrent);
		});
		retained = true;
		return Object.assign(ownerReceipt(owner), completionMethods);
	} finally {
		if (!retained) await store.release();
	}
}
/** Prepare evidence; only the later synchronous claim may spend recovered host custody. */
async function prepareSessionPendingInputDedupeRecovery(scope, runId) {
	const claim = prepareCurrentSessionPendingInputDedupeRecovery({
		...scope,
		sessionKey: resolveSqliteSessionKey(scope.sessionKey, scope.agentId)
	}, runId);
	if (!claim) return;
	const source = await readPendingInputSource(scope, `${runId}:user`, true);
	return source ? () => {
		source.assertCurrent();
		return claim(source.path, source.snapshot);
	} : void 0;
}
/** Read one admitted source for explicit retry comparison; this never authorizes replay. */
async function readSessionSubmittedInput(scope, idempotencyKey) {
	const source = await readPendingInputSource(scope, idempotencyKey, false);
	if (!source?.snapshot.current) return;
	source.assertCurrent();
	const { pending, committed } = source.snapshot;
	const message = pending ? parseSessionPendingInputMessage(pending.message_json) : committed;
	return message && readMessageIdempotencyKey(message) === idempotencyKey ? message : void 0;
}
//#endregion
//#region src/config/sessions/session-accessor.sqlite-recovery.ts
const log$1 = createSubsystemLogger("sessions/recovery");
/** Clone and publish through the canonical worker while retaining the caller's live authority. */
async function recoverSessionEntryFromRestartTombstone(params) {
	const { commitGuard, storePath, ...values } = params;
	const input = structuredClone(values);
	const scope = captureLifecycleDatabaseScope(await prepareSqliteScope({
		agentId: input.agentId,
		sessionKey: "",
		storePath,
		env: { ...process.env }
	}));
	const assertCurrent = () => commitGuard?.();
	assertCurrent();
	const options = {
		...toDatabaseOptions(scope),
		path: scope.path
	};
	let publication;
	let databaseIdentity;
	let admitted;
	return await withSessionEntryWorker(options, void 0, assertCurrent, async (execution, source) => {
		return await execution.runExisting(source, async (worker) => {
			databaseIdentity = execution.fileIdentity?.physicalIdentity;
			if (!databaseIdentity) throw new Error("Session recovery lost its admitted database identity");
			publication = retainSessionEntryWorkerPublication({
				agentId: scope.agentId,
				storePath: scope.path,
				databaseIdentity
			});
			const outcome = await worker.execute({
				type: "session.restart.recover",
				input
			}).then((value) => ({
				ok: true,
				value
			}), (error) => ({
				ok: false,
				error
			}));
			if (admitted) {
				await admitted.retained.settled;
				const facts = admitted.admission.committed?.facts;
				let receipt = outcome.ok ? outcome.value.publication : void 0;
				if (isRecord(facts) && facts.kind === "session-entry-replacements") receipt = facts;
				const unchanged = outcome.ok && outcome.value.result.status !== "created" || isRecord(facts) && facts.kind === "session-restart-recovery-unchanged";
				const unknown = admitted.admission.settlement?.kind !== "completed" || !receipt && !unchanged;
				const published = publication.settle(receipt, unknown);
				if (published) publishCommittedSessionIdentity(scope.agentId, databaseIdentity, published.previous, published.current, published.prepared);
				if (unknown) {
					const error = new SqliteWorkerError("Session recovery has no confirmed native completion and commit receipt", "outcome-unknown");
					error.cause = outcome.ok ? void 0 : outcome.error;
					throw error;
				}
				if (receipt) try {
					execution.assertCurrent();
					startSessionTranscriptIndexReconcile({
						...options,
						preferredSessionId: input.successorEntry.sessionId
					});
				} catch (error) {
					log$1.warn(`Recovery committed; transcript repair remains pending: ${formatErrorMessage(error)}`);
				}
			}
			if (!outcome.ok) throw outcome.error;
			return outcome.value.result;
		}) ?? {
			status: "conflict",
			reason: "not-tombstoned"
		};
	}, (admission, retained, facts) => {
		admitted = {
			admission,
			retained
		};
		if (!isRecord(facts) || facts.publication === void 0) return;
		const receipt = facts.publication;
		if (!isRecord(receipt) || receipt.kind !== "session-entry-replacements" || !Array.isArray(receipt.changedKeys) || !receipt.changedKeys.every((key) => typeof key === "string") || !publication) throw new Error("Session recovery commit omitted its publication keys");
		publication.begin(receipt.changedKeys, []);
	});
}
//#endregion
//#region src/config/sessions/session-sharing-store.receipt.ts
const participant = /* @__PURE__ */ lazyCompile(SessionParticipantSchema);
function requireReceipt(condition) {
	if (!condition) throw new SqliteWorkerError("Session collaboration receipt is incomplete or conflicting", "outcome-unknown");
}
function storedSuggestion(value) {
	return isRecord(value) && typeof value.id === "string" && typeof value.authorId === "string" && (value.authorLabel === void 0 || typeof value.authorLabel === "string") && typeof value.text === "string" && typeof value.createdAt === "number" && Number.isFinite(value.createdAt) && typeof value.state === "string" && [
		"pending",
		"accepted",
		"dismissed"
	].includes(value.state);
}
/** The native commit grant pins this candidate, including its committing connection incarnation. */
function readSessionCollaborationCandidate(value, command, keys, databaseIdentity) {
	requireReceipt(isRecord(value) && value.kind === "session-collaboration-committed" && value.type === command.type && Object.hasOwn(value, "result") && isRecord(value.publication) && isRecord(value.publication.source) && value.publication.source.identity === databaseIdentity && typeof value.publication.source.incarnation === "string" && value.publication.source.incarnation.length > 0);
	requireReceipt(hasSqliteCommitReceiptCoverage(value.publication, {
		source: {
			identity: databaseIdentity,
			incarnation: value.publication.source.incarnation
		},
		domain: "session-collaboration",
		keys
	}));
	const expected = new Map(keys.map((key) => [key, { kind: "unchanged" }]));
	const setFact = (key, fact) => {
		requireReceipt(expected.has(key));
		expected.set(key, {
			kind: "postimage",
			value: [fact]
		});
	};
	const result = value.result;
	const key = command.input.scope.sessionKey;
	if (command.type !== "category.apply") requireReceipt(keys.length === 1 && keys[0] === key);
	switch (command.type) {
		case "add":
		case "remove": {
			requireReceipt(isRecord(result));
			const adding = command.type === "add";
			if (adding) requireReceipt(isRecord(result.value) && typeof result.value.inserted === "boolean");
			const member = adding && isRecord(result.value) ? result.value.member : result.value;
			const changed = adding && isRecord(result.value) ? result.value.inserted : member !== null;
			const identityId = adding ? command.input.params.identityId.trim() : command.input.identityId.trim();
			if (member !== null) {
				requireReceipt(isRecord(member) && member.identityId === (adding ? identityId : toUSVString(identityId)) && typeof member.addedBy === "string" && typeof member.addedAt === "number" && Number.isFinite(member.addedAt));
				if (command.type === "add") requireReceipt(member.addedBy === command.input.params.addedBy.trim() && (command.input.params.addedAt === void 0 || member.addedAt === command.input.params.addedAt));
				else if (command.input.expected) requireReceipt(member.addedBy === command.input.expected.addedBy && member.addedAt === command.input.expected.addedAt);
			} else requireReceipt(!adding);
			if (changed) {
				const facts = result.facts;
				const sessionId = command.type === "add" ? command.input.params.expectedSessionId : command.input.expectedSessionId;
				requireReceipt(isRecord(facts) && typeof facts.sessionId === "string" && (sessionId === void 0 || sessionId === facts.sessionId));
				const fact = {
					kind: "member",
					sessionId: facts.sessionId,
					identityId: toUSVString(identityId),
					present: adding
				};
				requireReceipt(isDeepStrictEqual(facts, fact));
				setFact(key, fact);
			} else requireReceipt(result.facts === void 0);
			break;
		}
		case "owner.assign":
			requireReceipt(isRecord(result));
			if (result.value === null) requireReceipt(result.facts === void 0);
			else {
				const { params } = command.input;
				requireReceipt(isRecord(result.value) && typeof result.value.assignedAt === "number" && Number.isFinite(result.value.assignedAt));
				const owner = {
					actor: params.owner,
					assignedBy: params.assignedBy,
					assignedAt: params.assignedAt ?? result.value.assignedAt
				};
				requireReceipt(isDeepStrictEqual(result.value, owner));
				const facts = result.facts;
				requireReceipt(isRecord(facts) && typeof facts.sessionId === "string" && (params.expectedSessionId === void 0 || facts.sessionId === params.expectedSessionId) && (facts.lifecycleRevision === null || typeof facts.lifecycleRevision === "string"));
				const fact = {
					kind: "owner",
					sessionId: facts.sessionId,
					lifecycleRevision: facts.lifecycleRevision,
					owner
				};
				requireReceipt(isDeepStrictEqual(facts, fact));
				setFact(key, fact);
			}
			break;
		case "participant": {
			requireReceipt(isRecord(result) && (result.value === null || result.value === "inserted" || result.value === "updated" || result.value === "capped") && typeof result.projectionChanged === "boolean" && isRecord(result.participants));
			const projection = result.participants;
			let projected = {};
			if (projection.participants !== void 0) {
				requireReceipt(Array.isArray(projection.participants) && projection.participants.every(participant) && projection.participantCount === projection.participants.length);
				projected = {
					participants: projection.participants,
					participantCount: projection.participants.length
				};
			} else requireReceipt(projection.participantCount === void 0);
			requireReceipt(isDeepStrictEqual(projection, projected));
			if (result.projectionChanged) {
				requireReceipt(result.value === "inserted" || result.value === "updated");
				setFact(key, {
					kind: "participants",
					projection: projected
				});
			}
			break;
		}
		case "category.apply": {
			requireReceipt(Array.isArray(result) && result.length === keys.length);
			const seen = /* @__PURE__ */ new Set();
			for (const row of result) {
				requireReceipt(isRecord(row) && typeof row.sessionKey === "string" && typeof row.sessionId === "string" && !seen.has(row.sessionKey));
				seen.add(row.sessionKey);
				setFact(row.sessionKey, {
					kind: "category",
					sessionId: row.sessionId,
					category: command.input.to?.trim() || null
				});
			}
			break;
		}
		case "involvement":
			requireReceipt(isRecord(result) && typeof result.accepted === "boolean" && typeof result.changed === "boolean" && (!result.changed || result.accepted));
			if (result.changed) setFact(key, { kind: "unchanged" });
			break;
		case "suggestion.add":
			requireReceipt(storedSuggestion(result) && isRecord(result) && result.id === command.input.params.id && result.authorId === command.input.params.authorId.trim() && result.text === command.input.params.text && result.createdAt === command.input.params.createdAt && result.state === "pending");
			break;
		case "suggestion.finalize":
			requireReceipt(result === null || storedSuggestion(result) && isRecord(result) && result.id === toUSVString(command.input.params.id) && result.state === command.input.params.state);
			break;
		case "suggestion.release":
			requireReceipt(typeof result === "boolean");
			break;
		case "suggestion.claim":
			requireReceipt(result === null || isRecord(result) && (result.kind === "busy" || result.kind === "mismatch" && typeof result.resolution === "string" && [
				"send",
				"queue",
				"edit",
				"dismiss"
			].includes(result.resolution) || result.kind === "claimed" && typeof result.token === "string" && result.token.length > 0 && storedSuggestion(result.suggestion) && isRecord(result.suggestion) && result.suggestion.id === toUSVString(command.input.params.id)));
			break;
		case "category.prepare": requireReceipt(false);
	}
	requireReceipt(isDeepStrictEqual(value.publication.facts, expected));
	return value;
}
//#endregion
//#region src/config/sessions/session-sharing-store.async.ts
function toIncognitoCollaborationCommand(command, sessionKey) {
	switch (command.type) {
		case "add": return {
			type: "session.sharing.add",
			input: {
				sessionKey,
				params: command.input.params
			}
		};
		case "remove": {
			const { scope: _scope, ...input } = command.input;
			return {
				type: "session.sharing.remove",
				input: {
					...input,
					sessionKey
				}
			};
		}
		case "participant": return {
			type: "session.sharing.participant",
			input: {
				sessionKey,
				params: command.input.params
			}
		};
		case "owner.assign": return {
			type: "session.sharing.owner.assign",
			input: {
				sessionKey,
				params: command.input.params
			}
		};
		case "suggestion.add": return {
			type: "session.sharing.suggestion.add",
			input: {
				sessionKey,
				params: command.input.params
			}
		};
		case "suggestion.claim": return {
			type: "session.sharing.suggestion.claim",
			input: {
				sessionKey,
				params: command.input.params
			}
		};
		case "suggestion.release": return {
			type: "session.sharing.suggestion.release",
			input: {
				sessionKey,
				params: command.input.params
			}
		};
		case "suggestion.finalize": return {
			type: "session.sharing.suggestion.finalize",
			input: {
				sessionKey,
				params: command.input.params
			}
		};
	}
	throw new Error("Incognito collaboration command requires its dedicated owner");
}
async function runSessionCollaborationWrite(scope, command, native, publish, assertCurrent = () => void 0, prepare) {
	const resolved = resolveSqliteScope(scope);
	const resolvedOptions = toDatabaseOptions(resolved);
	const env = cloneEnvWithPlatformSemantics(resolved.env ?? process.env);
	env.OPENCLAW_STATE_DIR = resolveStateDir(env);
	const options = {
		...resolvedOptions,
		env,
		path: resolveOpenClawAgentSqlitePath({
			...resolvedOptions,
			env
		})
	};
	const location = {
		agentId: resolved.agentId,
		storePath: options.path,
		sessionKey: resolved.sessionKey
	};
	const capturedScope = {
		...location,
		env
	};
	const incognito = scope.incognito ?? captureIncognitoSessionOperation(scope);
	if (incognito) {
		const { actor, authority } = incognito;
		if (actor.agentId !== location.agentId || actor.path !== location.storePath) throw new Error("Collaboration target differs from its captured incognito actor");
		if (command.type === "category.prepare" || command.type === "category.apply") throw new Error("Incognito categories require the category owner composition");
		const currentAuthority = {
			assertCurrent() {
				assertCurrent();
				authority.assertCurrent();
				actor.assertCurrent();
			},
			authorize: (stage, facts) => authority.authorize?.(stage, facts)
		};
		currentAuthority.assertCurrent();
		if (command.type === "involvement") return publish({
			accepted: false,
			changed: false
		}, location, void 0);
		const actorCommand = toIncognitoCollaborationCommand(command, location.sessionKey);
		let published = false;
		const invalidate = () => {
			if (!published && !command.type.startsWith("suggestion.")) {
				sessionChanges.emit({
					...location,
					factsInvalidated: true
				});
				published = true;
			}
		};
		try {
			let value;
			await actor.sessions.sideData(currentAuthority, actorCommand, void 0, (result) => {
				value = publish(result, location, void 0);
				published = true;
			}, invalidate);
			return value;
		} catch (error) {
			invalidate();
			throw error;
		}
	}
	if (isIncognitoOpenClawAgentSqlitePath(options.path, options)) return runOpenClawAgentWriteAdmission(options, () => {
		assertCurrent();
		return native(capturedScope);
	}, true);
	const execution = captureOpenClawAgentDatabaseExecution(options);
	const assertQueuedCurrent = () => {
		execution.assertCurrent();
		assertCurrent();
	};
	const commandScope = {
		agentId: resolved.agentId,
		sessionKey: resolved.sessionKey,
		storePath: options.path,
		env: { OPENCLAW_STATE_DIR: env.OPENCLAW_STATE_DIR }
	};
	const capturedCommand = {
		type: command.type,
		input: structuredClone({
			...command.input,
			scope: commandScope
		})
	};
	try {
		return await runOpenClawAgentWriteAdmission(options, () => withOpenClawAgentDatabaseRuntime(options, async (database) => {
			const { db } = database;
			assertQueuedCurrent();
			const identity = readOpenClawAgentDatabaseIdentity(database).identity;
			if (typeof identity !== "string") throw new Error("Session collaboration worker requires a file-backed owner");
			const publication = retainSessionEntryWorkerPublication({
				...location,
				databaseIdentity: identity
			});
			let publicationKeys = [location.sessionKey];
			let mutationDispatched = false;
			let resultReceived = false;
			let receiptFailed = false;
			const publicationState = {};
			let activeAdmission;
			let mutationAdmission;
			let candidate;
			const worker = await openOpenClawAgentSqliteWorkerStore(options, db, {
				moduleUrl: resolveRuntimeWorkerUrl(runtimeProcessEntrypoints.sessionSharingStore),
				input: void 0,
				assertAdmission(request) {
					if (mutationDispatched && request.stage === "commit") {
						if (!isRecord(request.facts)) throw new SqliteWorkerError("Session collaboration commit omitted its candidate", "outcome-unknown");
						candidate = structuredClone(readSessionCollaborationCandidate(request.facts.publication, capturedCommand, publicationKeys, identity));
					}
					return request;
				},
				onAdmitted(request) {
					if (mutationDispatched && request.stage === "commit") {
						mutationAdmission = activeAdmission;
						if (!capturedCommand.type.startsWith("suggestion.")) {
							const memberships = /* @__PURE__ */ new Map();
							for (const [key, fact] of candidate?.publication.facts ?? []) if (fact.kind === "postimage" && fact.value[0]?.kind === "member") memberships.set(key, fact.value[0].sessionId);
							publication.beginChanges(publicationKeys, memberships);
						}
					}
				},
				observeAdmission(admission, retained) {
					activeAdmission = retained;
					observeSqliteWorkerCommittedFacts(admission, ({ facts }) => {
						if (!mutationDispatched || publicationState.result) return;
						try {
							if (!candidate || !isDeepStrictEqual(facts, candidate)) throw new SqliteWorkerError("Session collaboration receipt differs from its admitted candidate", "outcome-unknown");
							const receipt = candidate;
							const changes = [...receipt.publication.facts].flatMap(([sessionKey, fact]) => fact.kind === "postimage" ? fact.value.map((changeFacts) => ({
								...location,
								sessionKey,
								scope: "session-entry",
								facts: changeFacts
							})) : [{
								...location,
								sessionKey,
								facts: { kind: "unchanged" }
							}]);
							const result = receipt.result;
							if (!db.isOpen) {
								publication.settle(void 0, false);
								publicationState.result = { value: publish(result, location, void 0, /* @__PURE__ */ new Set()) };
							} else publicationState.result = { value: withSqliteCommittedPublications(db, () => publication.settleChanges(changes, (currentKeys, invalidations) => {
								const selected = publish(result, location, database, currentKeys);
								sessionChanges.emitBatch(invalidations, db);
								return selected;
							})) };
						} catch (error) {
							receiptFailed = true;
							throw error;
						}
					});
				}
			});
			try {
				await worker.run(async (operation) => {
					if (prepare) {
						const prepared = await prepare({ async execute(prepareCommand, executeOptions) {
							const result = await operation.execute(prepareCommand, executeOptions);
							if (prepareCommand.type === "category.prepare" && Array.isArray(result) && result.every((key) => typeof key === "string")) publicationKeys = result;
							return result;
						} }, commandScope);
						if (prepared) capturedCommand.input = structuredClone({
							...prepared,
							scope: commandScope
						});
					}
					assertQueuedCurrent();
					mutationDispatched = capturedCommand.type !== "category.prepare";
					await operation.execute(capturedCommand);
					resultReceived = true;
				}, assertQueuedCurrent);
				if (!publicationState.result) throw new SqliteWorkerError("Session collaboration omitted its native commit receipt", "outcome-unknown");
				return publicationState.result.value;
			} catch (error) {
				await mutationAdmission?.settled;
				if (publicationState.result) return publicationState.result.value;
				const unknown = mutationDispatched && (receiptFailed || resultReceived || collectNestedErrorCandidates(error).some((errorCandidate) => extractErrorCode(errorCandidate) === "outcome-unknown"));
				if (unknown && !capturedCommand.type.startsWith("suggestion.") && db.isOpen) publication.beginChanges(publicationKeys);
				publication.settle(void 0, unknown && db.isOpen);
				throw error;
			} finally {
				publication.settle(void 0, false);
				await worker.close();
			}
		}, assertQueuedCurrent), true);
	} finally {
		await execution.release();
	}
}
function publishSessionMembership({ facts }, location, database) {
	if (!database) sessionChanges.emit(facts ? {
		...location,
		facts
	} : {
		...location,
		factsInvalidated: true
	});
	else if (facts) publishSessionSharingMemberChange(database, location.sessionKey, facts, location.agentId);
	else sessionChanges.emit(bindSessionEntryPublicationSource({
		...location,
		factsInvalidated: true
	}, database), database.db);
}
function addSessionMemberInWorker(scope, params, assertCurrent) {
	const capturedParams = structuredClone({
		...params,
		addedAt: params.addedAt ?? Date.now()
	});
	return runSessionCollaborationWrite(scope, {
		type: "add",
		input: {
			scope,
			params: capturedParams
		}
	}, (capturedScope) => addSessionMember(capturedScope, capturedParams), (result, location, database, currentKeys) => {
		if (result.value.inserted && (!currentKeys || currentKeys.has(location.sessionKey))) publishSessionMembership(result, location, database);
		return result.value;
	}, assertCurrent);
}
function removeSessionMemberInWorker(scope, identityId, expected, expectedSessionId, assertCurrent, expectedEntry) {
	if (!identityId.trim()) return Promise.resolve(null);
	const capturedExpected = expected && structuredClone(expected);
	const capturedExpectedEntry = expectedEntry && structuredClone(expectedEntry);
	return runSessionCollaborationWrite(scope, {
		type: "remove",
		input: {
			scope,
			identityId,
			expected: capturedExpected,
			expectedSessionId,
			expectedEntry: capturedExpectedEntry
		}
	}, (capturedScope) => removeSessionMember(capturedScope, identityId, capturedExpected, expectedSessionId, capturedExpectedEntry), (result, location, database, currentKeys) => {
		if (result.value && (!currentKeys || currentKeys.has(location.sessionKey))) publishSessionMembership(result, location, database);
		return result.value;
	}, assertCurrent);
}
function recordSessionParticipantInWorker(scope, params) {
	if (!params.identity.id || params.identity.type === "agent" && params.identity.id === params.sessionAgentId) return Promise.resolve(null);
	const capturedParams = structuredClone({
		...params,
		promptedAt: params.promptedAt ?? Date.now()
	});
	return runSessionCollaborationWrite(scope, {
		type: "participant",
		input: {
			scope,
			params: capturedParams
		}
	}, (capturedScope) => recordSessionParticipant(capturedScope, capturedParams), (result, location, database, currentKeys) => {
		if ((result.value === "inserted" || result.value === "updated") && (!currentKeys || currentKeys.has(location.sessionKey))) {
			if (result.projectionChanged) {
				const change = {
					...location,
					scope: "session-entry",
					facts: {
						kind: "participants",
						projection: result.participants
					}
				};
				sessionChanges.emit(database ? bindSessionEntryPublicationSource(change, database) : change, database?.db);
			}
			const notify = () => emitSessionLifecycleEvent({
				agentId: location.agentId,
				sessionKey: location.sessionKey,
				reason: "participants",
				scope: "session-entry"
			});
			if (database) deferOpenClawAgentPostCommitPublication(database, notify);
			else notify();
		}
		return result.value;
	});
}
//#endregion
//#region src/config/sessions/session-involvement-store.ts
/** Released v2026.9.8 MentionInbox.recordCommittedInput completion contract. */
function updateSessionProfileInvolvement(scope, params) {
	const profiles = [...new Set(params.profileIds)].map((profileId) => ({
		profileId,
		aliases: [...readUserProfileAliases(profileId, { env: scope.env })]
	}));
	return updatePreparedSessionProfileInvolvement(scope, params, profiles).accepted;
}
async function updateSessionProfileInvolvementAsync(scope, { assertCurrent, ...params }) {
	const captured = structuredClone(params);
	let catalog;
	let profiles;
	const selectProfiles = (prepared) => [...new Set(captured.profileIds)].map((profileId) => {
		const identity = prepared.readCurrentIdentity(profileId);
		return {
			profileId: identity?.profileId ?? profileId,
			aliases: [.../* @__PURE__ */ new Set([profileId, ...identity?.aliases ?? []])]
		};
	});
	try {
		return await runSessionCollaborationWrite(scope, {
			type: "involvement",
			input: {
				scope,
				params: captured,
				profiles: []
			}
		}, () => false, (result, location, database, currentKeys) => {
			if (result.changed && database && (!currentKeys || currentKeys.has(location.sessionKey))) {
				publishSessionEntryCacheInvalidation(database, {
					sessionKey: location.sessionKey,
					facts: { kind: "unchanged" }
				});
				deferOpenClawAgentPostCommitPublication(database, () => emitSessionLifecycleEvent({
					agentId: location.agentId,
					sessionKey: location.sessionKey,
					reason: "involvement"
				}));
			}
			return result.accepted;
		}, () => {
			assertCurrent?.();
			if (catalog && profiles && !isDeepStrictEqual(selectProfiles(catalog), profiles)) throw new Error("Session involvement profile aliases changed before commit");
		}, async (_operation, capturedScope) => {
			catalog = await prepareUserProfileCatalog({ env: capturedScope.env });
			profiles = selectProfiles(catalog);
			return {
				scope: capturedScope,
				params: captured,
				profiles
			};
		});
	} finally {
		catalog?.release();
	}
}
//#endregion
//#region src/config/sessions/session-accessor.sqlite-canonical-inventory.ts
/** Doctor inventory hydrates rejected legacy blobs from promoted node/window columns. */
function hydrateCanonicalRepairEntry(row) {
	let record = {};
	try {
		const parsed = JSON.parse(row.entry_json);
		if (parsed && typeof parsed === "object" && !Array.isArray(parsed)) record = parsed;
	} catch {}
	attachSessionEntrySnapshots(record, row);
	const createdActor = row.created_actor_type ? {
		type: row.created_actor_type,
		...row.created_actor_type === "human" ? { source: "unknown" } : {},
		...row.created_actor_id ? { id: row.created_actor_id } : {}
	} : void 0;
	const forkSource = row.fork_source_session_key && row.fork_source_session_id ? {
		sessionKey: row.fork_source_session_key,
		sessionId: row.fork_source_session_id,
		...row.fork_source_entry_id ? { entryId: row.fork_source_entry_id } : {}
	} : void 0;
	const delivery = row.delivery_channel && row.delivery_target ? normalizeSessionDeliveryState({ context: {
		channel: row.delivery_channel,
		to: row.delivery_target,
		...row.delivery_account_id ? { accountId: row.delivery_account_id } : {},
		...row.delivery_thread_id ? { threadId: row.delivery_thread_id } : {}
	} }) : void 0;
	const entry = projectCanonicalSessionEntryShape({
		...record,
		...row.status ? { status: row.status } : {},
		...row.current_started_at !== null ? { startedAt: row.current_started_at } : {},
		...row.current_ended_at !== null ? { endedAt: row.current_ended_at } : {},
		...row.current_chat_type ? { chatType: row.current_chat_type } : {},
		...row.current_model_provider ? { modelProvider: row.current_model_provider } : {},
		...row.current_model ? { model: row.current_model } : {},
		...row.current_previous_session_id ? { previousSessionId: row.current_previous_session_id } : {},
		...row.current_agent_harness_id ? { agentHarnessId: row.current_agent_harness_id } : {},
		...delivery ? { delivery } : {},
		...row.created_at !== null ? { createdAt: row.created_at } : {},
		...row.created_via ? { createdVia: row.created_via } : {},
		...createdActor ? { createdActor } : {},
		...row.spawned_by ? { spawnedBy: row.spawned_by } : {},
		...row.parent_session_key && row.parent_session_key !== row.spawned_by ? { parentSessionKey: row.parent_session_key } : {},
		...forkSource ? { forkSource } : {},
		...row.label ? { label: row.label } : {},
		...row.display_name ? { displayName: row.display_name } : {},
		...row.category ? { category: row.category } : {},
		...row.icon ? { icon: row.icon } : {},
		...row.pinned_at !== null ? { pinnedAt: row.pinned_at } : {},
		...row.archived_at !== null ? { archivedAt: row.archived_at } : {},
		...row.last_read_at !== null ? { lastReadAt: row.last_read_at } : {},
		...row.last_interaction_at !== null ? { lastInteractionAt: row.last_interaction_at } : {},
		...row.last_activity_at !== null ? { lastActivityAt: row.last_activity_at } : {},
		sessionId: row.current_session_id,
		updatedAt: row.updated_at
	});
	return projectSqliteSessionOwner(entry, row);
}
function canonicalRepairQuery(database) {
	return getSessionKysely(database.db).selectFrom("session_nodes").leftJoin("session_windows as current_window", (join) => join.onRef("current_window.session_id", "=", "session_nodes.current_session_id").onRef("current_window.session_key", "=", "session_nodes.session_key")).leftJoin("session_windows as current_window_owner", "current_window_owner.session_id", "session_nodes.current_session_id").leftJoin("conversations as current_conversation", "current_conversation.conversation_id", "current_window.primary_conversation_id").selectAll("session_nodes").select(sessionEntrySnapshotColumns).select([
		"current_window_owner.session_key as current_window_owner_session_key",
		"current_window.started_at as current_started_at",
		"current_window.ended_at as current_ended_at",
		"current_window.chat_type as current_chat_type",
		"current_window.model_provider as current_model_provider",
		"current_window.model as current_model",
		"current_window.previous_session_id as current_previous_session_id",
		"current_window.agent_harness_id as current_agent_harness_id",
		"current_conversation.channel as delivery_channel",
		"current_conversation.account_id as delivery_account_id",
		"current_conversation.delivery_target",
		"current_conversation.thread_id as delivery_thread_id"
	]).orderBy("session_nodes.session_key");
}
function scanCanonicalSessionFactsFromDatabase(database, selectedKeys) {
	const scanned = [];
	const loaded = /* @__PURE__ */ new Map();
	const validSessionKeysById = /* @__PURE__ */ new Map();
	const inventoriedSessionKeys = /* @__PURE__ */ new Set();
	for (const row of iterateSqliteQuerySync(database.db, canonicalRepairQuery(database))) {
		inventoriedSessionKeys.add(row.session_key);
		const persistedEntry = parseSessionEntryJson(row);
		if (row.entry_valid === 1 && persistedEntry) {
			const keys = validSessionKeysById.get(row.current_session_id) ?? [];
			keys.push(row.session_key);
			validSessionKeysById.set(row.current_session_id, keys);
		}
		const entry = persistedEntry ?? hydrateCanonicalRepairEntry(row);
		if (selectedKeys?.has(row.session_key)) loaded.set(row.session_key, {
			entry,
			rawEntryJson: row.entry_json,
			rawSnapshotRevision: row.snapshot_revision
		});
		const lineageProjectionMismatch = Boolean(persistedEntry && ((row.parent_session_key ?? void 0) !== (persistedEntry.parentSessionKey ?? persistedEntry.spawnedBy ?? void 0) || (row.spawned_by ?? void 0) !== (persistedEntry.spawnedBy ?? void 0) || (row.fork_source_session_key ?? void 0) !== (persistedEntry.forkSource?.sessionKey ?? void 0)));
		const decision = {
			delivery: entry.delivery,
			forkSourceSessionKey: entry.forkSource?.sessionKey,
			groupId: entry.groupId,
			parentSessionKey: entry.parentSessionKey,
			rawCompareRequired: row.entry_valid !== 1 || !persistedEntry || lineageProjectionMismatch,
			sessionKey: row.session_key,
			spawnedBy: entry.spawnedBy
		};
		const context = deliveryContextFromSession(decision);
		const origin = sessionDeliveryOrigin(decision);
		scanned.push({
			currentSessionId: row.current_session_id,
			currentWindowOwnerSessionKey: row.current_window_owner_session_key,
			decision,
			entryJsonIsEmpty: row.entry_json === "{}",
			rowToken: JSON.stringify([
				row.session_key,
				row.current_session_id,
				row.entry_valid,
				row.snapshot_revision,
				persistedEntry !== null,
				row.entry_json === "{}",
				row.current_window_owner_session_key,
				context?.channel ?? null,
				context?.to ?? null,
				context?.threadId == null ? null : String(context.threadId),
				origin?.nativeChannelId ?? null,
				origin?.to ?? null,
				decision.groupId ?? null,
				decision.parentSessionKey ?? null,
				decision.spawnedBy ?? null,
				decision.forkSourceSessionKey ?? null,
				row.parent_session_key,
				row.spawned_by,
				row.fork_source_session_key,
				decision.rawCompareRequired
			])
		});
	}
	const inventoryHash = createHash("sha256");
	const facts = [];
	for (const fact of scanned) {
		const isEmptyWindowOwner = fact.entryJsonIsEmpty && fact.currentWindowOwnerSessionKey === fact.decision.sessionKey;
		const competingValidKeys = (validSessionKeysById.get(fact.currentSessionId) ?? []).filter((sessionKey) => sessionKey !== fact.decision.sessionKey).toSorted();
		const canonicalOwnerSessionKey = isEmptyWindowOwner ? competingValidKeys.length === 1 ? competingValidKeys[0] : void 0 : fact.entryJsonIsEmpty && fact.currentWindowOwnerSessionKey && inventoriedSessionKeys.has(fact.currentWindowOwnerSessionKey) ? fact.currentWindowOwnerSessionKey : void 0;
		const decisionToken = JSON.stringify([fact.rowToken, canonicalOwnerSessionKey ?? null]);
		inventoryHash.update(decisionToken).update("\0");
		if (!isEmptyWindowOwner || canonicalOwnerSessionKey) facts.push({
			...fact.decision,
			...canonicalOwnerSessionKey ? { canonicalOwnerSessionKey } : {},
			decisionToken
		});
	}
	const inventoryToken = inventoryHash.digest("base64url");
	return {
		facts: facts.map((fact) => Object.assign(fact, { inventoryToken })),
		inventoryToken,
		loaded
	};
}
function loadCanonicalRepairEntriesFromDatabase(database, facts) {
	const current = scanCanonicalSessionFactsFromDatabase(database, new Set(facts.map((fact) => fact.sessionKey)));
	const currentByKey = new Map(current.facts.map((fact) => [fact.sessionKey, fact]));
	const expectedInventoryTokens = new Set(facts.map((fact) => fact.inventoryToken));
	if (expectedInventoryTokens.size !== 1 || !expectedInventoryTokens.has(current.inventoryToken)) throw new Error("Canonical session repair inputs changed during scan; retry Doctor");
	return facts.map((fact) => {
		if (currentByKey.get(fact.sessionKey)?.decisionToken !== fact.decisionToken) throw new Error(`Canonical session repair inputs changed during scan for ${fact.sessionKey}; retry Doctor`);
		const loaded = current.loaded.get(fact.sessionKey);
		if (!loaded) throw new Error(`Canonical session repair row disappeared during scan: ${fact.sessionKey}`);
		const summary = {
			entry: loaded.entry,
			sessionKey: fact.sessionKey
		};
		return fact.rawCompareRequired ? {
			...summary,
			rawEntryJson: loaded.rawEntryJson,
			rawSnapshotRevision: loaded.rawSnapshotRevision
		} : summary;
	});
}
function listCanonicalSessionRepairFacts(scope) {
	const resolved = resolveSqliteScope({
		...scope,
		sessionKey: ""
	});
	const result = withOpenClawAgentDatabaseReadOnly((database) => scanCanonicalSessionFactsFromDatabase(database).facts, toDatabaseOptions(resolved));
	return result.found ? result.value : [];
}
function loadCanonicalSessionRepairEntries(scope, facts) {
	if (facts.length === 0) return [];
	const resolved = resolveSqliteScope({
		...scope,
		sessionKey: ""
	});
	const result = withOpenClawAgentDatabaseReadOnly((database) => loadCanonicalRepairEntriesFromDatabase(database, facts), toDatabaseOptions(resolved));
	if (!result.found) throw new Error("Canonical session repair database disappeared during scan; retry Doctor");
	return result.value;
}
/** Strict Doctor scan of canonical rows, ordered by durable session key. */
function scanDoctorSessionEntriesStrict(scope, visit) {
	const resolved = resolveSqliteScope({
		...scope,
		sessionKey: ""
	});
	const result = withOpenClawAgentDatabaseReadOnly((database) => {
		let count = 0;
		scanCanonicalSqliteSessionEntries(database, ({ entry, sessionKey }) => {
			if (isInternalSessionEffectsKey(sessionKey)) return;
			visit({
				entry,
				recoveredFromProjections: false,
				sessionKey
			});
			count += 1;
		});
		return count;
	}, toDatabaseOptions(resolved));
	return result.found ? result.value : 0;
}
/** Tolerant Doctor preview scan with canonical-repair tombstone eligibility. */
function scanDoctorSessionEntriesTolerant(scope, visit) {
	const resolved = resolveSqliteScope({
		...scope,
		sessionKey: ""
	});
	const result = withOpenClawAgentDatabaseReadOnly((database) => {
		const eligible = new Set(scanCanonicalSessionFactsFromDatabase(database).facts.map((fact) => fact.sessionKey));
		let count = 0;
		for (const row of iterateSqliteQuerySync(database.db, canonicalRepairQuery(database))) {
			if (!eligible.has(row.session_key) || isInternalSessionEffectsKey(row.session_key)) continue;
			const entry = parseSessionEntryJson(row);
			visit({
				entry: entry ?? hydrateCanonicalRepairEntry(row),
				recoveredFromProjections: entry === null,
				sessionKey: row.session_key
			});
			count += 1;
		}
		return count;
	}, toDatabaseOptions(resolved));
	return result.found ? result.value : 0;
}
//#endregion
//#region src/config/sessions/session-accessor.sqlite-branch-list.ts
const pendingBranchReads = /* @__PURE__ */ new Map();
async function listSessionBranches(params, suppliedIncognito) {
	const sourceKey = normalizeStoreSessionKey(params.sessionStoreKey ?? params.sessionKey);
	const incognito = suppliedIncognito ?? captureIncognitoSessionHistoryBinding({
		...params,
		sessionKey: sourceKey
	});
	if (incognito) {
		const result = await readIncognitoSessionHistory(incognito, {
			...params,
			sessionKey: sourceKey,
			sessionId: incognito.target.sessionId
		}, (target) => ({
			type: "session.history.branches",
			input: target
		}));
		return result.status === "ok" ? {
			status: "ok",
			branches: result.branches
		} : result;
	}
	const resolved = resolveSqliteScope({
		...params.agentId ? { agentId: params.agentId } : {},
		...params.env ? { env: params.env } : {},
		sessionKey: sourceKey,
		...params.storePath ? { storePath: params.storePath } : {}
	});
	try {
		const retained = retainOpenClawAgentDatabaseReadOnly(toDatabaseOptions(resolved));
		if (!retained.found) return { status: "missing-session" };
		const { database, claim } = retained;
		const completion = createDeferredCore();
		const controller = new AbortController();
		let unregister = () => {};
		try {
			const selected = readSessionEntryRow(database, sourceKey, "list")?.entry;
			if (!selected?.sessionId) return { status: "missing-session" };
			const expected = {
				sessionKey: sourceKey,
				sessionId: selected.sessionId,
				lifecycleRevision: selected.lifecycleRevision
			};
			const assertCurrent = () => {
				controller.signal.throwIfAborted();
				claim.assertCurrent();
			};
			unregister = registerOpenClawAgentDatabaseAsyncResource({
				agentId: database.agentId,
				path: database.path,
				revoke: () => controller.abort(/* @__PURE__ */ new Error("Session branch read was revoked")),
				close: () => completion.promise
			});
			const watermark = readSessionTranscriptHotWatermark(database, selected.sessionId);
			const cached = readCachedSessionBranchSummaries(database, selected.sessionId, watermark);
			let snapshot;
			if (cached?.maxSeq === watermark.maxSeq) snapshot = {
				status: "ok",
				...cached
			};
			else if (typeof claim.identity === "symbol") snapshot = readSessionBranchSnapshot(database, {
				...expected,
				previous: cached
			});
			else {
				const request = {
					database: {
						agentId: database.agentId,
						path: database.path
					},
					databaseIdentity: claim.identity,
					validation: getOpenClawAgentDatabaseValidation(database),
					...expected
				};
				const key = JSON.stringify([
					request,
					claim.incarnation,
					watermark
				]);
				snapshot = await getOrCreatePromise(pendingBranchReads, key, async () => {
					const { runSessionBranchSummaryWorkerRequest } = await import("./session-transcript-worker-runtime-D5GwnkHX.mjs");
					const read = () => {
						assertCurrent();
						return runSessionBranchSummaryWorkerRequest({
							...request,
							previous: cached
						}, controller.signal);
					};
					try {
						return await read();
					} catch (error) {
						if (!(error instanceof SessionTranscriptColdError)) throw error;
						return readRestoredSessionTranscript({
							...params,
							agentId: resolved.agentId,
							sessionId: selected.sessionId
						}, read, { assertCurrent });
					}
				}, { evictOnSettled: true });
			}
			assertCurrent();
			const current = readSessionEntryRow(database, sourceKey, "list")?.entry;
			if (current?.sessionId !== expected.sessionId || current.lifecycleRevision !== expected.lifecycleRevision) return { status: "failed" };
			if (snapshot.status !== "ok") return snapshot;
			cacheSessionBranchSummaries(database, selected.sessionId, snapshot);
			return {
				status: "ok",
				branches: cloneSessionBranchSummaries(snapshot.branches)
			};
		} finally {
			try {
				claim.release();
			} finally {
				completion.resolve();
				unregister();
			}
		}
	} catch {
		return { status: "failed" };
	}
}
//#endregion
//#region src/config/sessions/session-manual-compact.ts
/** Keep the admitted physical owner and host authority until the combined write settles. */
function trimSessionTranscriptInWorker(scope, input, authority) {
	const database = {
		...toDatabaseOptions(scope),
		path: scope.path
	};
	const sources = authority.source?.checks.map(({ predicate }) => predicate) ?? [];
	let sourceMatches = [];
	let sourceValidation;
	const assertCurrent = () => {
		authority.assertCurrent();
		if (!sourceValidation) return;
		authority.source?.assertCurrent();
		for (const match of sourceValidation.conversationMatches) {
			const matches = sourceMatches.find(({ index }) => index === match.index).matches;
			const accepted = match.acceptedAlternatives ?? match.alternatives;
			for (let alternative = 0; alternative < matches.length - 1; alternative++) Atomics.store(matches, alternative + 1, accepted.includes(alternative) ? 1 : 0);
		}
	};
	return runSessionEntryWorkerOperation({
		database,
		databaseIdentity: authority.databaseIdentity,
		agentId: scope.agentId,
		candidateKind: "session-manual-compact",
		assertCurrent,
		onTransactionFacts(facts) {
			if (!isRecord(facts) || facts.kind !== "session-manual-compact-validated") return false;
			const validated = facts;
			sourceValidation = validated.sourceValidation;
			sourceMatches = validated.sourceMatches;
			if (authority.source) acceptSessionSourceValidation(authority.source, sourceValidation);
			assertCurrent();
			return true;
		},
		run: (worker, commit) => commit(() => executeSessionMessageRewriteOperation(worker, database.agentId, {
			type: "session.transcript.manualCompact",
			input: {
				...input,
				scope,
				sources
			}
		})),
		onCommitted(candidate, published, identity) {
			if (published) publishCommittedSessionIdentity(scope.agentId, identity, published.previous, published.current, published.prepared);
			return candidate.result;
		}
	});
}
//#endregion
//#region src/config/sessions/session-transcript-stats.ts
/** Read hot and cold statistics through the captured database's existing executor. */
function readTranscriptStatsAsync(scope) {
	const incognitoSource = captureIncognitoSessionSource(scope);
	if (incognitoSource && "kind" in incognitoSource) {
		incognitoSource.assertCurrent();
		return Promise.resolve({
			eventCount: 0,
			maxSeq: 0,
			sizeBytes: 0
		});
	}
	const incognito = captureIncognitoSessionHistoryBinding(scope);
	if (incognito) return readIncognitoSessionHistory(incognito, scope, (target) => ({
		type: "session.history.stats",
		input: target
	}));
	return withSessionTranscriptReadSource(scope, readTranscriptStatsSync, ({ scope: captured, resolved, expectedIdentity, assertCurrent }) => withSessionEntryWorker({
		...toDatabaseOptions(resolved),
		path: captured.storePath
	}, expectedIdentity?.key.slice(5), assertCurrent, async (execution, source) => {
		const result = await execution.runExisting(source, (worker) => executeOpenClawAgentWorkerPublication(worker, {
			id: randomUUID(),
			moduleUrl: resolveRuntimeWorkerUrl(runtimeProcessEntrypoints.sessionTranscriptStats).href,
			input: void 0,
			command: {
				type: "read",
				input: { sessionId: resolved.sessionId }
			}
		}));
		assertCurrent();
		return result ?? {
			eventCount: 0,
			maxSeq: 0,
			sizeBytes: 0
		};
	}));
}
//#endregion
//#region src/config/sessions/session-accessor.sqlite-compaction-runtime.ts
/** Commit transcript and accounting together through the existing SessionManager writer. */
async function persistCompactionBoundaryWithSessionEntryAsync(scope, params, assertActive) {
	assertActive?.();
	const captured = withOwnedSessionTranscriptWriterFence({
		...captureSessionTranscriptTargetBinding(scope),
		expectedLifecycleRevision: scope.expectedLifecycleRevision,
		expectedWriterRunId: scope.expectedWriterRunId,
		...scope.expectedOwner ? { expectedOwner: { ...scope.expectedOwner } } : {}
	});
	const { scope: preparedScope, ...append } = params.prepared;
	const prepared = {
		...structuredClone(append),
		scope: withOwnedSessionTranscriptWriterFence({
			...captureSessionTranscriptTargetBinding(preparedScope),
			expectedLifecycleRevision: preparedScope.expectedLifecycleRevision,
			expectedWriterRunId: preparedScope.expectedWriterRunId,
			...preparedScope.expectedOwner ? { expectedOwner: { ...preparedScope.expectedOwner } } : {}
		})
	};
	if (!sameSessionTranscriptStorageEnvironment(captured.env, prepared.scope.env)) throw new SessionTranscriptWriterClaimReboundError();
	const assertOwned = captureOwnedTranscriptWriteAssertion(captured);
	const assertPreparedOwned = captureOwnedTranscriptWriteAssertion(prepared.scope);
	const initialWriter = getOwnedSessionTranscriptInitialWriter({ sessionTarget: prepared.scope });
	const assertCurrent = () => {
		assertActive?.();
		assertOwned();
		assertPreparedOwned();
		initialWriter?.assertActive();
	};
	const options = toDatabaseOptions(resolveSqliteTranscriptScope(captured));
	const actor = captureSessionManagerIncognitoBinding(captured)?.actor;
	const transcriptByteCompactionLatch = { ...params.transcriptByteCompactionLatch };
	return await trackAsyncWork(() => runOpenClawAgentWriteAdmission(options, async () => {
		assertCurrent();
		if (isIncognitoSessionKey(captured.sessionKey) && !actor) return persistCompactionBoundaryWithSessionEntrySync(captured, {
			prepared,
			transcriptByteCompactionLatch
		});
		const { withSessionMetadataWorker } = await runInDetachedAsyncContext(() => import("./session-manager-metadata-runtime-Cb_DI10a.mjs"));
		assertCurrent();
		const persist = (database) => withSessionMetadataWorker(options, database, assertCurrent, async (worker) => {
			const { env: _env, ...target } = captured;
			const { env: _preparedEnv, ...preparedTarget } = prepared.scope;
			const acknowledged = await receiveSessionManagerCommit("session.transcript.compactionBoundary", () => worker.execute({
				type: "session.transcript.compactionBoundary",
				input: {
					scope: actor ? {
						...target,
						storePath: actor.path
					} : target,
					prepared: {
						...prepared,
						scope: actor ? {
							...preparedTarget,
							storePath: actor.path
						} : preparedTarget
					},
					transcriptByteCompactionLatch,
					...initialWriter && !initialWriter.committedFence ? { initialWriterRunId: initialWriter.writerRunId } : {}
				}
			}));
			const receipt = acknowledged.value;
			try {
				if (receipt.initialEntry?.fence && !("db" in database)) initialWriter?.recordCommitted(receipt.initialEntry.fence);
			} finally {
				if (receipt.initialEntry?.identity && !("db" in database)) publishCommittedSessionIdentity(captured.agentId, database.identity.incarnation, receipt.initialEntry.identity.previous, receipt.initialEntry.identity.current);
			}
			if (acknowledged.failure) throw new SessionEntryCommittedError(receipt.committed.result.id, captured, receipt.committed.after, acknowledged.failure);
			if (receipt.projectionNeedsReconcile) startSessionTranscriptIndexReconcile({
				...options,
				preferredSessionId: captured.sessionId
			});
			return receipt.committed;
		}, { initialWriter });
		return actor ? await persist(actor) : await withOpenClawAgentDatabaseRuntime(options, persist, assertCurrent);
	}, true));
}
//#endregion
//#region src/config/sessions/session-transcript-message-presence.ts
/** Read the cold marker and both message probes in the history worker's one snapshot. */
function hasSessionTranscriptMessage(scope, suppliedIncognito) {
	const incognito = suppliedIncognito ?? captureIncognitoSessionHistoryBinding(scope);
	if (incognito) return readIncognitoSessionHistory(incognito, scope, (target) => ({
		type: "session.history.message-presence",
		input: target
	}));
	return withSessionTranscriptReadSource(scope, (captured) => {
		const resolved = resolveSqliteTranscriptReadScope(captured);
		const database = openOpenClawAgentDatabase(toDatabaseOptions(resolved));
		return hasSessionTranscriptMessageInDatabase(database, resolved.sessionId);
	}, ({ scope: captured, resolved, owner, expectedIdentity, assertCurrent }) => readRestoredSessionTranscript(captured, () => owner.readMessagePresence({
		scope: captured,
		expectedIdentity
	}), {
		assertCurrent,
		coldRead: {
			target: resolved,
			readMetadata: async () => {
				const metadata = await owner.readColdMetadata({
					sessionId: resolved.sessionId,
					env: captured.env ?? {}
				});
				assertCurrent();
				return metadata.archive;
			}
		}
	}));
}
//#endregion
//#region src/config/sessions/session-accessor.sqlite-transcript-message-rewrite.ts
/** Rewrites one exact anchored message without rejecting unrelated later appends. */
async function rewriteTranscriptMessageAtAnchor(anchor, rewriteMessage) {
	const resolved = resolveSqliteTranscriptScope(anchor);
	return await runExclusiveSqliteSessionWrite(resolved, async () => runOpenClawAgentWriteTransaction((database) => {
		assertSessionTranscriptHot(database.db, resolved.sessionId);
		const row = executeSqliteQueryTakeFirstSync(database.db, getSessionKysely(database.db).selectFrom("transcript_events").select(transcriptEventJsonSql(database.db).as("event_json")).where("session_id", "=", resolved.sessionId).where("seq", "=", anchor.rawSeq));
		if (!row) return null;
		const event = JSON.parse(row.event_json);
		if (!isRecord(event) || event.type !== "message" || event.id !== anchor.entryId) return null;
		const message = rewriteMessage(event.message);
		if (message === void 0) return null;
		rewriteSqliteTranscriptEventRowsInTransaction(database, resolved, [{
			event: {
				...event,
				message
			},
			expectedEventJson: row.event_json,
			seq: anchor.rawSeq
		}]);
		const generation = readTranscriptGenerationInTransaction(database, resolved.sessionId);
		return generation ? {
			generation,
			message
		} : null;
	}, toDatabaseOptions(resolved), { operationLabel: "session.transcript.message-rewrite" }), "session.transcript.message-rewrite");
}
/** Updates the terminal assistant owned by one run, preserving unrelated later turns. */
async function rewriteAssistantTranscriptMessageForRun(params, preparedScope) {
	const scope = withOwnedSessionTranscriptWriterFence({
		...params.scope,
		expectedLifecycleRevision: params.expectedLifecycleRevision ?? void 0
	});
	const resolved = preparedScope ?? resolveSqliteTranscriptScope(scope);
	const { restoreSessionColdTranscript } = await import("./session-cold-storage-L7zFwmx1.mjs");
	await restoreSessionColdTranscript({
		...scope,
		sessionId: resolved.sessionId,
		...preparedScope ? { storePath: resolved.path } : {}
	}, preparedScope ? () => assertOwnedTranscriptWriteCommit(scope) : void 0);
	return await runExclusiveSqliteSessionWrite(resolved, async () => runOpenClawAgentWriteTransaction((database) => {
		assertSessionTranscriptHot(database.db, resolved.sessionId);
		assertOwnedTranscriptWriteCommit(scope);
		const current = readSessionEntryRow(database, resolved.sessionKey)?.entry;
		if (!transcriptWriteScopeIsCurrent(current, resolved.sessionId, scope) || current?.lifecycleRevision !== (params.expectedLifecycleRevision ?? void 0)) throw new SessionTranscriptWriterClaimReboundError();
		const event = findTranscriptEventInDatabase(database, resolved.sessionId, (event) => {
			if (!isRecord(event) || !isRecord(event.message)) return false;
			return readSessionTranscriptRunId(event.message) === params.runId && resolveTerminalAssistantTranscriptRunId(event.message, params.runId) !== void 0;
		})?.event;
		if (!isRecord(event) || typeof event.id !== "string" || !isRecord(event.message)) return null;
		const identity = readTranscriptIdentityByEventId(database, resolved.sessionId, event.id);
		if (!identity) return null;
		const message = params.rewriteMessage(event.message);
		if (!isDeepStrictEqual(message, event.message)) rewriteSqliteTranscriptEventRowsInTransaction(database, resolved, [{
			event: {
				...event,
				message
			},
			expectedEventJson: JSON.stringify(event),
			seq: identity.seq
		}]);
		return { messageId: event.id };
	}, toDatabaseOptions(resolved), { operationLabel: "session.transcript.assistant-rewrite" }), "session.transcript.message-rewrite");
}
//#endregion
//#region src/config/sessions/session-accessor.transcript.ts
/**
* Trims a transcript for manual sessions.compact and clears stale token metadata.
* This is one storage-sized mutation: future stores can trim transcript rows and
* update entry metadata inside the same backend transaction.
*/
async function preflightSessionTranscriptForManualCompact(scope, params) {
	const { eventCount } = await readTranscriptStatsAsync(scope);
	if (eventCount === 0) return {
		compacted: false,
		reason: "no transcript"
	};
	return eventCount > Math.max(1, Math.floor(params.maxLines)) ? { compacted: true } : {
		compacted: false,
		kept: eventCount
	};
}
async function trimSessionTranscriptForManualCompact(scope, params) {
	const authority = params.authority;
	const incognito = captureIncognitoSessionOperation(scope);
	if (!authority && incognito) return trimPreparedSessionTranscriptForManualCompact(scope, params);
	if (!authority) return withSessionTranscriptReadSource(scope, (captured) => trimPreparedSessionTranscriptForManualCompact({
		...captured,
		sessionKey: scope.sessionKey
	}, params), async ({ scope: captured, resolved, expectedIdentity, assertCurrent }) => {
		const { restoreSessionColdTranscript } = await import("./session-cold-storage-L7zFwmx1.mjs");
		assertCurrent();
		await restoreSessionColdTranscript(captured, assertCurrent);
		assertCurrent();
		return trimSessionTranscriptInWorker({
			...resolved,
			sessionKey: resolved.sessionKey ?? scope.sessionKey,
			path: captured.storePath
		}, params, {
			assertCurrent,
			databaseIdentity: expectedIdentity?.key.slice(5)
		});
	});
	const assertEntryCurrent = (entry) => {
		if (!entry || entry.sessionId !== scope.sessionId || entry.lifecycleRevision !== authority.expectedLifecycleRevision || resolveSessionWorkStartError(scope.sessionKey, entry)) throw new SessionWorkStartChangedError("Session changed before compaction. Retry.");
	};
	if (incognito) {
		const { actor } = incognito;
		const expected = authority.expectedSource;
		if (expected && (expected.path !== actor.path || expected.agentId !== actor.agentId || expected.databaseIdentity !== actor.identity.incarnation)) throw new Error("Session compaction changed its physical actor");
		return actor.sessions.withSharedState(async () => {
			const source = await prepareSessionSourceAuthority(authority.source);
			try {
				if (source.nativeSource || source.hasOpaqueCheck || source.checks.some(({ predicate }) => predicate.source.path !== actor.path || predicate.source.agentId !== actor.agentId || predicate.source.databaseIdentity !== actor.identity.incarnation)) throw new Error("Incognito compaction requires source authority prepared for its actor");
				const assertCurrent = () => {
					incognito.authority.assertCurrent();
					authority.assertHostCurrent();
					(source.assertPreparedCurrent ?? source.assertCurrent)();
				};
				assertCurrent();
				return await trimPreparedSessionTranscriptForManualCompact(scope, params, {
					assertEntryCurrent,
					assertCurrent,
					assertCommitCurrent: assertCurrent,
					source,
					restore: async () => {}
				});
			} finally {
				await releaseSessionSourceAuthorities([source]);
			}
		});
	}
	return withSessionTranscriptReadSource(scope, (captured) => trimPreparedSessionTranscriptForManualCompact({
		...captured,
		sessionKey: scope.sessionKey
	}, params, {
		assertEntryCurrent,
		assertCurrent: authority.source,
		assertCommitCurrent: authority.source,
		restore: async () => {
			const { restoreSessionColdTranscript } = await import("./session-cold-storage-L7zFwmx1.mjs");
			authority.source();
			await restoreSessionColdTranscript(captured, authority.assertHostCurrent);
			authority.source();
		}
	}), async ({ scope: captured, resolved, owner, expectedIdentity, assertCurrent: assertReader }) => {
		const expectedSource = authority.expectedSource;
		const assertPhysicalSource = () => {
			if (expectedSource && typeof expectedSource.databaseIdentity === "string") {
				if (captured.storePath !== expectedSource.path) throw new Error("Session compaction changed its physical store");
				assertExistingDatabaseIdentity(captured.storePath, `file:${expectedSource.databaseIdentity}`, expectedSource.databaseBirthtime);
			}
		};
		assertPhysicalSource();
		const source = await prepareSessionSourceAuthority(authority.source);
		const nativeCommit = source.nativeSource || source.hasOpaqueCheck;
		try {
			const assertOwnerCurrent = () => {
				assertReader();
				assertPhysicalSource();
				authority.assertHostCurrent();
			};
			const assertCurrent = () => {
				assertOwnerCurrent();
				if (source.assertPreparedCurrent) source.assertPreparedCurrent();
				else if (!nativeCommit) source.assertCurrent();
			};
			assertCurrent();
			const sources = source.checks.map(({ predicate }) => predicate);
			const read = await owner.readExactEntries({
				sessionKeys: [scope.sessionKey],
				projection: "exact",
				expectedIdentity: expectedIdentity && {
					...expectedIdentity,
					canonicalPath: captured.storePath
				},
				env: captured.env,
				manualCompact: {
					sessionId: resolved.sessionId,
					sources
				}
			});
			assertCurrent();
			const refused = read.manualCompact?.refusedSource;
			if (refused) source.checks[refused.index].refuse(refused.facts);
			assertEntryCurrent(read.entries[0]?.entry);
			if (nativeCommit) authority.source();
			const preparation = {
				snapshot: read.entries,
				assertEntryCurrent,
				assertCurrent,
				assertCommitCurrent: () => {
					assertCurrent();
					authority.source();
				},
				restore: async () => {
					const { restoreSessionColdTranscript, SessionColdSourceReboundError, SessionColdTurnReboundError } = await import("./session-cold-storage-L7zFwmx1.mjs");
					assertCurrent();
					try {
						await restoreSessionColdTranscript(captured, assertCurrent, {
							target: resolved,
							acceptSourceValidation: (validation) => acceptSessionSourceValidation(source, validation),
							readMetadata: async (phase) => phase === "initial" ? read.manualCompact?.archive : (await owner.readColdMetadata({
								sessionId: resolved.sessionId,
								env: captured.env
							})).archive
						}, {
							kind: "turn",
							agentId: resolved.agentId,
							sessionKey: scope.sessionKey,
							options: {
								keyFormat: "agent-qualified",
								expectedSessionId: resolved.sessionId,
								selectedSessionId: resolved.sessionId,
								selectedLifecycleRevision: authority.expectedLifecycleRevision ?? null
							},
							sources,
							requireActive: true
						});
					} catch (error) {
						if (error instanceof SessionColdTurnReboundError) throw new SessionWorkStartChangedError(error.message);
						if (error instanceof SessionColdSourceReboundError) source.checks[error.refusal.index].refuse(error.refusal.facts);
						throw error;
					}
					assertCurrent();
				}
			};
			if (nativeCommit) return await trimPreparedSessionTranscriptForManualCompact({
				...captured,
				sessionKey: scope.sessionKey
			}, params, preparation);
			await preparation.restore();
			assertCurrent();
			return await trimSessionTranscriptInWorker({
				...resolved,
				sessionKey: resolved.sessionKey ?? scope.sessionKey,
				path: captured.storePath
			}, {
				maxLines: params.maxLines,
				nowMs: params.nowMs,
				entries: read.entries
			}, {
				assertCurrent: assertOwnerCurrent,
				source,
				databaseIdentity: expectedIdentity?.key.slice(5)
			});
		} finally {
			await releaseSessionSourceAuthorities([source]);
		}
	});
}
async function trimPreparedSessionTranscriptForManualCompact(scope, params, preparation) {
	let declined = {
		compacted: false,
		reason: "no transcript"
	};
	const trimmed = await trimTranscriptForManualCompact(scope, (lines) => {
		const selected = selectManualCompactTranscriptLines(lines, params.maxLines);
		declined = selected.result;
		return selected.result.compacted ? selected.lines : null;
	}, {
		nowMs: params.nowMs,
		preparation
	});
	if (!trimmed.trimmed) return declined;
	return {
		compacted: true,
		kept: trimmed.kept
	};
}
//#endregion
//#region src/config/sessions/session-accessor.transcript-turn.ts
function resolveTranscriptTurnAgentId(params) {
	if (classifySessionKeyShape(params.sessionKey) === "malformed_agent") throw new Error("Malformed agent session key; refusing transcript turn persistence.");
	const scopedAgentId = params.scopeAgentId?.trim() ? normalizeAgentId(params.scopeAgentId) : void 0;
	const parsedAgentId = parseAgentSessionKey(params.sessionKey)?.agentId;
	const keyAgentId = parsedAgentId ? normalizeAgentId(parsedAgentId) : void 0;
	if (scopedAgentId && keyAgentId && scopedAgentId !== keyAgentId) throw new Error(`Session key owner "${keyAgentId}" does not match requested agent "${scopedAgentId}".`);
	const incognito = captureIncognitoSessionOperation({
		agentId: scopedAgentId,
		sessionKey: params.sessionKey,
		storePath: params.storePath,
		env: params.env
	});
	if (incognito) return incognito.actor.agentId;
	const persistedStoreOwner = params.sessionStore && !params.storePath ? { kind: "none" } : resolvePersistedSessionStoreOwnerForTarget({
		config: params.config,
		sessionKey: params.sessionKey,
		storePath: params.storePath,
		env: params.env
	});
	if (scopedAgentId && persistedStoreOwner.kind === "configured" && scopedAgentId !== persistedStoreOwner.agentId) throw new AgentSelectionRequiredError(listAgentIds(params.config), {
		surface: "transcript turn persistence",
		hint: `The shared fixed-store row belongs to agent "${persistedStoreOwner.agentId}", not agent "${scopedAgentId}".`
	});
	if (persistedStoreOwner.kind === "retired") throw new AgentSelectionRequiredError(listAgentIds(params.config), {
		surface: "transcript turn persistence",
		hint: `The shared fixed-store row belongs to retired agent "${persistedStoreOwner.agentId}".`
	});
	const agentId = keyAgentId ?? (persistedStoreOwner.kind === "configured" ? persistedStoreOwner.agentId : void 0) ?? scopedAgentId ?? tryResolveLegacyCompatibilityAgentId(params.config);
	if (agentId) return normalizeAgentId(agentId);
	throw new AgentSelectionRequiredError(listAgentIds(params.config), {
		surface: "transcript turn persistence",
		hint: "Pass an agentId or use an agent-qualified session key."
	});
}
/** Appends one prepared ordered group in the existing transcript turn transaction. */
async function appendTranscriptMessages(scope, options) {
	if (options.messages.length === 0) return [];
	const expectedSessionId = scope.sessionId?.trim();
	if (!expectedSessionId) throw new Error("Cannot append a transcript batch without an exact session id");
	const turn = await persistExpectedSessionTranscriptTurn(scope, {
		atomicGroup: true,
		config: options.config,
		cwd: options.cwd,
		expectedSessionId,
		messages: options.messages.map((append) => ({
			...append,
			eventId: append.eventId ?? randomUUID(),
			message: redactTranscriptMessageForStorage(append.message, options),
			now: append.now ?? Date.now()
		})),
		updateMode: "none"
	});
	if (turn.rejectedReason) throw new Error("Transcript session changed before batch append");
	return turn.messages;
}
/**
* Persists one logical transcript turn through the SQLite-backed session target.
* Transcript row append(s) and the requested
* updatedAt touch happen before transcript update delivery is published.
*/
async function persistSessionTranscriptTurn(scope, options) {
	const expectedSessionId = options.expectedSessionId;
	if (expectedSessionId) return await persistExpectedSessionTranscriptTurn(scope, {
		...options,
		expectedSessionId
	});
	if (options.messages.some((append) => append.workerPreparation?.prepareMessageAfterIdempotencyCheckAsync)) throw new Error("Awaited transcript preparation requires an expected session id");
	if (options.sessionLifecyclePatch || options.sessionTurnMutation || options.initialSessionEntry) throw new Error("Cannot mutate a session turn without an expected session id");
	const target = await prepareTranscriptTurnTarget(scope, options.config);
	const previousSessionEntry = (scope.sessionStore ? resolveSessionStoreEntryCore({
		store: scope.sessionStore,
		sessionKey: target.sessionKey
	}) : void 0)?.existing ?? scope.sessionEntry;
	if (target.selectedSessionId != null && target.storePath && target.sessionKey && target.sessionId) return await persistExpectedSessionTranscriptTurn({
		...scope,
		...target
	}, {
		...options,
		expectedSessionId: target.sessionId
	}, target);
	const appendedMessages = await runWithOwnedSessionTranscriptWrite({
		sessionFile: target.sessionKey,
		sessionKey: target.sessionKey,
		sessionTarget: target
	}, () => appendTranscriptTurnMessages(target, options));
	const appendedCount = appendedMessages.filter((message) => message.appended).length;
	let sessionEntry = previousSessionEntry;
	if (options.touchSessionEntry === true && appendedCount > 0 && target.storePath && target.sessionKey && target.sessionId) {
		const updatedAt = Date.now();
		const updated = await updateSessionEntry({
			sessionKey: target.sessionKey,
			storePath: target.storePath,
			...target.agentId ? { agentId: target.agentId } : {},
			...target.env ? { env: target.env } : {}
		}, (current) => current.sessionId === target.sessionId ? { updatedAt: Math.max(current.updatedAt ?? 0, updatedAt) } : null, { skipMaintenance: true });
		if (updated && scope.sessionStore) scope.sessionStore[target.sessionKey] = updated;
		sessionEntry = updated ?? previousSessionEntry;
	}
	await publishTranscriptTurnUpdate({
		target,
		sessionEntry,
		updateMode: options.updateMode ?? "inline",
		publishWhen: options.publishWhen ?? "when-appended",
		appendedMessages,
		runId: options.runId
	});
	return {
		appendedCount,
		messages: appendedMessages,
		sessionEntry
	};
}
async function appendTranscriptTurnMessages(target, options) {
	const selectedMessages = [];
	for (const append of options.messages) if (!append.shouldAppend || await append.shouldAppend({
		...target.agentId ? { agentId: target.agentId } : {},
		...target.sessionId ? { sessionId: target.sessionId } : {},
		...target.sessionKey ? { sessionKey: target.sessionKey } : {},
		...target.storePath ? { storePath: target.storePath } : {}
	})) selectedMessages.push(append);
	const appendedMessages = [];
	for (const append of selectedMessages) {
		const { shouldAppend: _shouldAppend, workerPreparation, ...appendOptions } = append;
		const result = await appendTranscriptMessage({
			...target.agentId ? { agentId: target.agentId } : {},
			...target.env ? { env: target.env } : {},
			...target.sessionId ? { sessionId: target.sessionId } : {},
			...target.sessionKey ? { sessionKey: target.sessionKey } : {},
			...target.storePath ? { storePath: target.storePath } : {}
		}, {
			...appendOptions,
			...workerPreparation,
			message: attachSessionTranscriptRunId(appendOptions.message, options.runId),
			...append.cwd ?? options.cwd ? { cwd: append.cwd ?? options.cwd } : {},
			...append.config ?? options.config ? { config: append.config ?? options.config } : {}
		});
		if (result) {
			const completion = completeSessionTranscriptCommit([result], options.onMessageCommitted);
			if (completion) await completion;
			appendedMessages.push(result);
		}
	}
	rememberCommittedTranscriptMessageSequences(target, appendedMessages);
	return appendedMessages;
}
async function persistExpectedSessionTranscriptTurn(scope, options, preparedTarget) {
	const requestedSessionKey = scope.sessionKey?.trim();
	const expectedSessionId = options.expectedSessionId;
	const onCommittedSource = captureSessionTranscriptSourcePublication({
		...scope,
		sessionId: expectedSessionId
	});
	const { selectedSessionId, selectedLifecycleRevision, ...target } = preparedTarget ?? await prepareTranscriptTurnTarget({
		...scope,
		sessionId: expectedSessionId
	}, options.config);
	const inheritedWriterFence = getOwnedSessionTranscriptWriterFence({
		sessionFile: target.sessionKey,
		sessionKey: target.sessionKey,
		sessionTarget: target
	});
	const turn = await runWithOwnedSessionTranscriptWrite({
		sessionFile: target.sessionKey,
		sessionKey: target.sessionKey,
		sessionTarget: target
	}, () => appendExpectedSessionTranscriptTurn(target, {
		config: options.config,
		cwd: options.cwd,
		keyFormat: "agent-qualified",
		selectedSessionId,
		selectedLifecycleRevision,
		expectedLifecycleRevision: options.expectedLifecycleRevision !== void 0 ? options.expectedLifecycleRevision : inheritedWriterFence?.expectedLifecycleRevision,
		expectedWriterRunId: options.expectedWriterRunId ?? inheritedWriterFence?.expectedWriterRunId,
		expectedSessionState: options.expectedSessionState,
		assertCurrent: options.assertCurrent,
		acceptedResultGuard: options.acceptedResultGuard,
		expectedSessionId,
		initialSessionEntry: options.initialSessionEntry,
		atomicGroup: options.atomicGroup,
		messages: options.messages.map((append) => ({
			...append,
			message: attachSessionTranscriptRunId(append.message, options.runId)
		})),
		onMessageCommitted: options.onMessageCommitted,
		onCommittedSource,
		sessionLifecyclePatch: options.sessionLifecyclePatch,
		sessionTurnMutation: options.sessionTurnMutation,
		sessionFile: target.sessionKey,
		touchSessionEntry: options.touchSessionEntry
	}));
	if (turn.rejectedReason === "session-rebound") return {
		appendedCount: 0,
		messages: [],
		rejectedReason: "session-rebound",
		sessionEntry: turn.sessionEntry
	};
	await publishTranscriptTurnUpdate({
		target: requestedSessionKey === target.sessionKey ? target : {
			...target,
			sessionKey: requestedSessionKey
		},
		sessionEntry: turn.sessionEntry,
		updateMode: options.updateMode ?? "inline",
		publishWhen: options.publishWhen ?? "when-appended",
		appendedMessages: turn.appendedMessages,
		runId: options.runId
	});
	if (turn.sessionEntry && scope.sessionStore) scope.sessionStore[target.sessionKey] = turn.sessionEntry;
	return {
		sessionTurnMutationResult: turn.sessionTurnMutationResult,
		predicateSkipped: turn.predicateSkipped,
		appendedCount: turn.appendedMessages.filter((message) => message.appended).length,
		messages: turn.appendedMessages,
		sessionEntry: turn.sessionEntry ?? scope.sessionEntry
	};
}
async function prepareTranscriptTurnTarget(scope, config) {
	const sessionKey = scope.sessionKey?.trim();
	if (!sessionKey || !scope.sessionId) throw new Error("Cannot persist a transcript turn without a session key and session id");
	const effectiveConfig = config ?? getRuntimeConfig();
	const agentId = resolveTranscriptTurnAgentId({
		config: effectiveConfig,
		scopeAgentId: scope.agentId,
		sessionKey,
		storePath: scope.storePath,
		sessionStore: scope.sessionStore,
		env: scope.env
	});
	const storePath = scope.storePath ?? resolveSessionStorePathCore(effectiveConfig.session?.store, {
		agentId,
		env: scope.env
	});
	const binding = captureSessionTranscriptTargetBinding({
		agentId,
		...scope.env ? { env: scope.env } : {},
		sessionId: scope.sessionId,
		sessionKey,
		storePath
	});
	return {
		...await resolveSessionTranscriptRuntimeTarget(binding, config, { keyFormat: "agent-qualified" }),
		storePath: binding.storePath,
		env: binding.env
	};
}
async function publishTranscriptTurnUpdate(params) {
	if (params.updateMode === "none") return;
	const appendedMessages = params.appendedMessages.filter((message) => message.appended);
	if (params.publishWhen === "when-appended" && appendedMessages.length === 0) return;
	const target = params.target.agentId && params.target.sessionId && params.target.sessionKey ? {
		agentId: params.target.agentId,
		sessionId: params.target.sessionId,
		sessionKey: params.target.sessionKey,
		...params.target.storePath ? { storePath: params.target.storePath } : {}
	} : void 0;
	const update = {
		...params.target.sessionKey ? { sessionKey: params.target.sessionKey } : {},
		...params.target.agentId ? { agentId: params.target.agentId } : {},
		...target ? { target } : {},
		...params.sessionEntry?.lifecycleRevision ? { lifecycleRevision: params.sessionEntry.lifecycleRevision } : {}
	};
	if (params.updateMode !== "inline" || appendedMessages.length === 0) {
		emitSessionTranscriptUpdate(update);
		return;
	}
	const sequencedMessages = appendedMessages.map((message) => ({
		message,
		messageSeq: readCommittedTranscriptMessageSequence(message)
	}));
	if (sequencedMessages.length > 1 && sequencedMessages.some(({ messageSeq }) => messageSeq === void 0)) {
		emitSessionTranscriptUpdate(update);
		return;
	}
	for (const { message, messageSeq } of sequencedMessages) {
		const runId = resolveTerminalAssistantTranscriptRunId(message.message, params.runId);
		emitSessionTranscriptUpdate({
			...update,
			message: message.message,
			messageId: message.messageId,
			...messageSeq !== void 0 ? { messageSeq } : {},
			...runId ? { runId } : {}
		});
	}
}
//#endregion
//#region src/config/sessions/session-accessor.sqlite-transcript-reports.ts
const log = createSubsystemLogger("sessions/transcript-reports");
/** Inactive composition: routing must supply the already captured actor at activation. */
async function withIncognitoReportWorker(scope, binding, run) {
	const { actor, authority: source } = binding;
	const fenced = withOwnedSessionTranscriptWriterFence({
		...scope,
		env: captureSessionTranscriptStorageEnvironment(scope.env ?? process.env)
	});
	assertSqliteTranscriptWriteIdentity(fenced);
	if (!isIncognitoSessionKey(fenced.sessionKey)) throw new Error("An incognito report requires an incognito session key");
	const resolved = resolveSqliteTranscriptScope(fenced);
	if (resolved.agentId !== actor.agentId || resolved.path !== actor.path) throw new Error("Transcript report differs from its retained incognito actor");
	const assertOwned = captureOwnedTranscriptWriteAssertion(fenced);
	const assertCurrent = () => {
		actor.assertCurrent();
		source.assertCurrent();
		assertOwned();
	};
	assertCurrent();
	const authority = {
		assertCurrent,
		authorize: (stage, facts) => source.authorize?.(stage, facts)
	};
	const target = {
		sessionKey: resolved.sessionKey,
		sessionId: resolved.sessionId,
		fence: {
			expectedLifecycleRevision: fenced.expectedLifecycleRevision,
			expectedWriterRunId: fenced.expectedWriterRunId
		}
	};
	const settled = await actor.sessions.withSharedState(async () => {
		let prepared;
		let reconcile = false;
		const commands = {
			prepare: async (selection) => {
				prepared = void 0;
				const selectionResult = await actor.sessions.transcript(authority, {
					type: "session.report.prepare",
					input: {
						...target,
						selection
					}
				});
				if (!selectionResult.ok) return selectionResult;
				prepared = selectionResult.value.prepared;
				return ok(selectionResult.value.facts);
			},
			append: (report) => {
				if (!prepared) throw new Error("Incognito report append requires its prepared selection");
				return actor.sessions.transcript(authority, {
					type: "session.report.append",
					input: {
						...target,
						prepared,
						report
					}
				});
			},
			assistant: (report) => actor.sessions.transcript(authority, {
				type: "session.report.assistant",
				input: {
					...target,
					report
				}
			}),
			abortedPartial: (report) => actor.sessions.transcript(authority, {
				type: "session.report.abortedPartial",
				input: {
					...target,
					report
				}
			})
		};
		const result = await settleReportOperation(() => run({ execute: ({ type, input }) => commands[type](input) }, assertCurrent, (publication) => {
			reconcile ||= publication.projectionNeedsReconcile;
		}), async () => {
			if (reconcile) await reconcileSessionTranscriptIndexes({
				agentId: actor.agentId,
				path: actor.path,
				env: fenced.env,
				preferredSessionId: target.sessionId
			}, {
				actor,
				authority,
				target: {
					...target,
					lifecycleRevision: fenced.expectedLifecycleRevision
				}
			});
		});
		if (!result.ok && fenced.expectedWriterRunId !== void 0) throw new SessionTranscriptWriterClaimReboundError(result.error);
		return result;
	});
	assertCurrent();
	actor.assertReadable();
	return settled;
}
async function settleReportOperation(operation, cleanup) {
	let result;
	try {
		result = ok(await operation());
	} catch (error) {
		result = err(error);
	}
	try {
		await cleanup();
	} catch (error) {
		if (!result.ok) throw createSqliteLifecycleAggregateError([result.error, error], "Transcript report and cleanup failed", result.error);
		try {
			log.warn(`Transcript report completed before cleanup failed: ${formatErrorMessage(error)}`);
		} catch {}
	}
	if (!result.ok) throw result.error;
	return result.value;
}
async function withNativeCurrentTranscript(scope, run) {
	const fenced = withOwnedSessionTranscriptWriterFence(scope);
	const resolved = resolveSqliteTranscriptScope(fenced);
	return runExclusiveSqliteSessionWrite(resolved, async () => runOpenClawAgentWriteTransaction((database) => {
		assertOwnedTranscriptWriteCommit(fenced);
		const refusal = resolveTranscriptAppendRefusal(readSessionEntryRow(database, resolved.sessionKey, "list")?.entry, resolved, fenced);
		if (refusal) {
			if (fenced.expectedWriterRunId !== void 0) throw new SessionTranscriptWriterClaimReboundError(refusal);
			return err(refusal);
		}
		const result = run(database, resolved);
		assertOwnedTranscriptWriteCommit(fenced);
		const rebound = resolveTranscriptAppendRefusal(readSessionEntryRow(database, resolved.sessionKey, "list")?.entry, resolved, fenced);
		if (rebound) throw new SessionTranscriptWriterClaimReboundError(rebound);
		return ok(result);
	}, toDatabaseOptions(resolved), { operationLabel: "session.transcript.report" }), "session.transcript.report");
}
async function withReportWorker(scope, kind, run, sessionEntryCurrent, incognito) {
	if (incognito) {
		if (sessionEntryCurrent) throw new Error("A file session source cannot authorize an incognito transcript report");
		try {
			return await withIncognitoReportWorker(scope, incognito, run);
		} catch (error) {
			if (error instanceof Error && error.name === "SyntaxError") throw new SyntaxError(error.message, { cause: error });
			throw error;
		}
	}
	const fenced = withOwnedSessionTranscriptWriterFence({
		...scope,
		...scope.storePath ? { storePath: path.resolve(scope.storePath) } : {},
		env: captureSessionTranscriptStorageEnvironment(scope.env ?? process.env)
	});
	const assertOwned = captureOwnedTranscriptWriteAssertion(fenced);
	assertSqliteTranscriptWriteIdentity(fenced);
	assertOwned();
	const source = sessionEntryCurrent?.source;
	const storePath = fenced.storePath ?? resolveOpenClawAgentSqlitePath(toDatabaseOptions(resolveSqliteScope(fenced)));
	const candidates = captureSessionStoreReadCandidates(storePath);
	const identities = captureSessionStoreCandidateIdentities(candidates);
	const sourceIdentity = source ? readDatabasePathIdentitySync(source.path) : void 0;
	const assertSourceCurrent = () => {
		if (!source) return;
		assertExistingDatabaseIdentity(source.path, `file:${source.databaseIdentity}`, source.databaseBirthtime);
	};
	assertSourceCurrent();
	const targetScope = {
		...fenced,
		storePath
	};
	const admission = resolveSqliteWriteAdmissionScope(targetScope);
	const prepare = async () => {
		const resolved = captureLifecycleDatabaseScope({
			...await prepareSqliteScope(targetScope),
			sessionId: fenced.sessionId
		});
		if (admission && resolved.path !== admission.path) throw new Error("Transcript report preparation changed its reserved database path");
		const databaseOptions = toDatabaseOptions(resolved);
		const options = {
			...databaseOptions,
			path: resolveOpenClawAgentSqlitePath(databaseOptions)
		};
		const physicalPath = assertSessionStoreReadCandidate(options.path, candidates);
		if (source && (resolved.sessionKey !== source.sessionKey || databaseOptions.agentId !== source.agentId || physicalPath !== sourceIdentity?.canonicalPath)) throw new Error("Transcript report target differs from its session source restriction");
		const identity = identities.get(physicalPath) ?? readDatabasePathIdentitySync(options.path);
		if (!identities.has(physicalPath) && identity.key.startsWith("file:")) throw new Error("Transcript report target appeared after source capture");
		const assertTargetCurrent = () => {
			assertSourceCurrent();
			assertSessionStoreReadCandidate(options.path, candidates);
			if (identity.key.startsWith("file:")) assertExistingDatabaseIdentity(options.path, identity.key, identity.birthtime);
			assertOwned();
		};
		assertTargetCurrent();
		const operate = async () => {
			assertTargetCurrent();
			const execution = captureOpenClawAgentDatabaseExecution(options, identity.key.startsWith("file:") ? { expectedIdentity: {
				kind: "file",
				physicalIdentity: identity.key.slice(5),
				nativeLocation: identity.canonicalPath,
				birthtime: identity.birthtime
			} } : { expectedCreationIdentity: identity });
			const cliWriter = kind === "append" ? getCliHistoryWriter({
				...resolved,
				storePath: resolveOpenClawAgentSqlitePath(options)
			}) : void 0;
			const assertCurrent = () => {
				execution.assertCurrent();
				assertTargetCurrent();
				cliWriter?.assertCurrent();
			};
			const { env: _env, ...workerResolved } = resolved;
			const target = {
				resolved: workerResolved,
				sessionEntryCurrentSource: sessionEntryCurrent?.source,
				...cliWriter ? { cliWriter: {
					runId: cliWriter.runId,
					authFingerprint: cliWriter.authFingerprint,
					lifecycleRevision: cliWriter.lifecycleRevision
				} } : {},
				fence: {
					expectedLifecycleRevision: fenced.expectedLifecycleRevision,
					expectedWriterRunId: fenced.expectedWriterRunId
				}
			};
			try {
				const result = await settleReportOperation(async () => {
					await prepareSessionEntryReplacementDatabase(options, assertCurrent, execution);
					assertCurrent();
					const databaseIdentity = execution.fileIdentity?.physicalIdentity;
					if (!databaseIdentity) throw new Error("Transcript report has no prepared native database identity");
					const worker = await openOpenClawAgentSqliteWorkerStore(options, { execution }, {
						moduleUrl: resolveRuntimeWorkerUrl(runtimeProcessEntrypoints.sessionTranscriptReports),
						input: target,
						assertAdmission: (request) => request.stage === "transaction" || request.stage === "commit" ? assertSessionEntryCurrentAdmission(request, sessionEntryCurrent) : request
					});
					return settleReportOperation(() => worker.run((operation) => run(operation, assertCurrent, (publication) => {
						if (publication.cliHistoryChanged || publication.sessionEntryChanged) publishSessionEntryWorkerMetadataInvalidation({
							agentId: resolved.agentId,
							storePath: execution.path,
							databaseIdentity,
							sessionKey: resolved.sessionKey
						});
						if (publication.projectionNeedsReconcile) startSessionTranscriptIndexReconcile({
							...options,
							preferredSessionId: resolved.sessionId
						});
					}), assertCurrent), () => worker.close());
				}, () => execution.release());
				if (!result.ok && fenced.expectedWriterRunId !== void 0) throw new SessionTranscriptWriterClaimReboundError(result.error);
				return result;
			} catch (error) {
				if (error instanceof Error && error.name === "SyntaxError") throw new SyntaxError(error.message, { cause: error });
				throw error;
			}
		};
		return admission ? operate() : runExclusiveSqliteSessionWrite(resolved, operate, "session.transcript.report");
	};
	return admission ? runExclusiveSqliteSessionWrite(admission, prepare, "session.transcript.report") : prepare();
}
function isProcessHeldTranscript(scope) {
	return isIncognitoSessionKey(scope.sessionKey) || Boolean(scope.storePath && isIncognitoOpenClawAgentSqlitePath(scope.storePath, {
		agentId: scope.agentId ?? resolveAgentIdFromSessionKey(scope.sessionKey),
		env: scope.env
	}));
}
/** Fills a hot transcript only when its settled registered producer left no authoritative answer. */
async function appendAbortedSessionTranscriptPartial(scope, partial, incognito) {
	const binding = incognito ?? captureIncognitoSessionOperation(scope);
	const publicationScope = {
		...scope,
		...binding ? { env: captureSessionTranscriptStorageEnvironment(scope.env ?? process.env) } : {}
	};
	const { config, ...input } = partial;
	const preparedMessage = prepareTranscriptMessageAppend({
		message: attachSessionTranscriptRunId(partial.message, partial.runId),
		config
	});
	if (!preparedMessage || preparedMessage.persistedMessage.role !== "assistant") throw new Error("Aborted partial requires prepared assistant storage bytes");
	const settlement = !binding && isProcessHeldTranscript(publicationScope) ? await withNativeCurrentTranscript(publicationScope, (database, resolved) => appendAbortedSessionTranscriptPartialInTransaction(database, resolved, input, preparedMessage)) : await withReportWorker(publicationScope, "append", async (operation, _assertCurrent, publish) => {
		const result = await operation.execute({
			type: "abortedPartial",
			input: {
				...input,
				message: preparedMessage.persistedMessage,
				preparedMessage
			}
		});
		if (!result.ok) return result;
		const receipt = result.value.abortedPartial;
		if (!receipt) throw new Error("Aborted partial worker returned no settlement receipt");
		publish(result.value);
		return ok(receipt);
	}, void 0, binding);
	if (settlement.ok && !settlement.value.skipped && settlement.value.append.appended) {
		const { append, lifecycleRevision, messageSeq } = settlement.value;
		await publishTranscriptUpdate(publicationScope, {
			lifecycleRevision,
			messageSeq,
			message: append.message,
			messageId: append.messageId,
			runId: input.runId
		});
	}
	return settlement;
}
/** Reads the latest matching custom report from the active branch in one snapshot. */
async function readLatestSessionTranscriptReport(scope, customTypes, incognito) {
	const binding = incognito ?? captureIncognitoSessionOperation(scope);
	const selectedTypes = [...customTypes];
	if (!binding && isProcessHeldTranscript(scope)) return withNativeCurrentTranscript(scope, (database, resolved) => prepareTranscriptReportSelection(database, resolved, {
		kind: "custom",
		customTypes: selectedTypes
	}).latest);
	return withReportWorker(scope, "read", async (operation, assertCurrent) => {
		const prepared = await operation.execute({
			type: "prepare",
			input: {
				kind: "custom",
				customTypes: selectedTypes
			}
		});
		assertCurrent();
		return prepared.ok ? ok(prepared.value.latest) : prepared;
	}, void 0, binding);
}
/** Selects and appends one report against the same authoritative branch revision. */
async function appendSessionTranscriptReport(scope, report, options) {
	const incognito = options?.incognito ?? captureIncognitoSessionOperation(scope);
	if (!incognito && isProcessHeldTranscript(scope)) {
		if (options?.sessionEntryCurrent) throw new Error("A file session source cannot authorize a process-held transcript report");
		return withNativeCurrentTranscript(scope, (database, resolved) => appendSessionTranscriptReportInTransaction(database, resolved, report));
	}
	if (report.kind === "assistant") {
		const preparedMessage = prepareTranscriptMessageAppend({ message: applyAssistantDeliveryDirectives(report.message) });
		if (!preparedMessage) throw new Error("Assistant report requires prepared transcript storage bytes");
		const input = {
			...report,
			message: preparedMessage.persistedMessage,
			preparedMessage
		};
		return withReportWorker(scope, "append", async (operation, _assertCurrent, publish) => {
			const result = await operation.execute({
				type: "assistant",
				input
			});
			if (!result.ok) return result;
			publish(result.value);
			return ok(void 0);
		}, options?.sessionEntryCurrent, incognito);
	}
	const selection = {
		kind: report.kind,
		customTypes: [...report.customTypes],
		suppressWhenAssistantRun: report.suppressWhenAssistantRun
	};
	const selectReport = report.selectReport;
	return withReportWorker(scope, "append", async (operation, assertCurrent, publish) => {
		for (let attempt = 0; attempt < 3; attempt++) {
			const prepared = await operation.execute({
				type: "prepare",
				input: selection
			});
			assertCurrent();
			if (!prepared.ok) return prepared;
			if (prepared.value.suppressed) return ok(void 0);
			const selected = selectReport(prepared.value.latest);
			assertCurrent();
			if (!selected) return ok(void 0);
			const input = prepareCustomTranscriptReport(selected, prepared.value.appendParentId);
			assertCurrent();
			const result = await operation.execute({
				type: "append",
				input
			});
			if (!result.ok) return result;
			if (result.value.committed) {
				publish(result.value);
				return ok(void 0);
			}
		}
		throw new Error("Session transcript kept changing while selecting its report");
	}, options?.sessionEntryCurrent, incognito);
}
//#endregion
export { withSessionPendingInputPersistence as A, runSessionCollaborationWrite as C, readSessionSubmittedInput as D, prepareSessionPendingInputDedupeRecovery as E, recoverSessionTranscriptProjection as M, readWithdrawnSessionPendingInputId as O, removeSessionMemberInWorker as S, bindSessionPendingInputSources as T, scanDoctorSessionEntriesTolerant as _, persistSessionTranscriptTurn as a, addSessionMemberInWorker as b, rewriteAssistantTranscriptMessageForRun as c, persistCompactionBoundaryWithSessionEntryAsync as d, readTranscriptStatsAsync as f, scanDoctorSessionEntriesStrict as g, loadCanonicalSessionRepairEntries as h, appendTranscriptMessages as i, normalizeMessageClientSources as j, stageSessionPendingInput as k, rewriteTranscriptMessageAtAnchor as l, listCanonicalSessionRepairFacts as m, appendSessionTranscriptReport as n, preflightSessionTranscriptForManualCompact as o, listSessionBranches as p, readLatestSessionTranscriptReport as r, trimSessionTranscriptForManualCompact as s, appendAbortedSessionTranscriptPartial as t, hasSessionTranscriptMessage as u, updateSessionProfileInvolvement as v, recoverSessionEntryFromRestartTombstone as w, recordSessionParticipantInWorker as x, updateSessionProfileInvolvementAsync as y };
